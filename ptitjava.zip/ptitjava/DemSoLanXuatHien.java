package com.mycompany.ptitjava;


import java.util.*;
public class DemSoLanXuatHien {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        for(int v = 1; v <= t; v++){
            int[] res = new int[100005];
            int n = sc.nextInt();
            int[] x = new int[105];
            for(int i = 0; i < n; i++){
                x[i] = sc.nextInt();
                res[x[i]] += 1;
            }
            System.out.println("Test " + v + ":");
            for(int i = 0; i < n; i++){
                if(x[i] != -1){
                    System.out.println(x[i] +  " xuat hien " + res[x[i]] + " lan");
                    for(int j = i + 1; j < n; ++j){
                        if(x[j] == x[i]){
                            x[j] = -1;
                        }
                    }
                }
            }
        }
        
    }
}
