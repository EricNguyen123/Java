/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.Scanner;
public class HinhVuong {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int xMax = -1001, xMin = 1001, yMax = -1001, yMin = 1001;
        int x, y;
        for(int i = 0; i < 4; i++){
            x = sc.nextInt();
            y = sc.nextInt();
            xMax = Math.max(xMax, x);
            xMin = Math.min(xMin, x);
            yMax = Math.max(yMax, y);
            yMin = Math.min(yMin, y);
        }
        int lMax = Math.max(xMax - xMin, yMax - yMin);
        int s = lMax * lMax;
        System.out.println(s);
    }
}
