/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
class DonHang{
    String ma, ten;
    int sl, dg, tck, tt;
    DonHang(String ten, int sl, int dg, int code){
        this.ten = ten;
        this.dg = dg;
        this.sl = sl;
        if(this.sl > 10){
            this.tck = this.dg * this.sl * 5 / 100;
        }
        else if(8 <= this.sl && this.sl <= 10){
            this.tck = this.dg * this.sl * 2 / 100;
        }
        else if(5 <= this.sl && this.sl < 8){
            this.tck = this.dg * this.sl * 1 / 100;
        }
        this.ma = "" + this.ten.charAt(0);
        for(int i = 0; i < this.ten.length(); i++){
            if(this.ten.charAt(i) == ' '){
                this.ma += this.ten.charAt(i + 1);
                break;
                
            }
            
        }
        this.ma = this.ma.toUpperCase();
        String v = String.valueOf(code);
        while(v.length() < 2){
            v = "0" + v;
        }
        this.ma = this.ma + v;
        this.tt = this.dg * this.sl - this.tck;
    }
   
}
public class BangKeNhapKho {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        DonHang[] dh = new DonHang[t];
        
        for(int i = 0; i < t; i++){
            String x = sc.nextLine();
            String ten = sc.nextLine();
            int sl = sc.nextInt(), dg = sc.nextInt();
            
            String c = "" + ten.charAt(0);
            for(int ii = 0; ii < ten.length(); ii++){
                if(ten.charAt(ii) == ' '){
                    c += ten.charAt(ii + 1);
                    break;

                }

            }
            int b = 0;
            
            c = c.toUpperCase();
            for(int j = i - 1; j >= 0; j--){
                String cc = "" + dh[j].ma.charAt(0) + dh[j].ma.charAt(1);
                if(c.equals(cc)){
                    
                    b = ((int)dh[j].ma.charAt(2) - 48) * 10 + (int)dh[j].ma.charAt(3) - 48 + 1;
                    break;
                }
                
            }
            if(b == 0){
                
                b += 1;
            }
            dh[i] = new DonHang(ten, sl, dg, b);
            
        }
        for(int i = 0; i < t; i++){
            System.out.println(dh[i].ma + " " + dh[i].ten + " " + dh[i].tck + " " + dh[i].tt);
        }
    }
}