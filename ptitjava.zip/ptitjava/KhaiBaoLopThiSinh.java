/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
import java.text.*;
public class KhaiBaoLopThiSinh {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();
        String date = sc.nextLine();
        float a = sc.nextFloat();
        float b = sc.nextFloat();
        float c = sc.nextFloat();
        float x = a + b + c;
        DecimalFormat f = new DecimalFormat("0.0");
        System.out.print(name + " " + date + " " + f.format(x));
    }
}
