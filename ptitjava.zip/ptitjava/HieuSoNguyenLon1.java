/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
public class HieuSoNguyenLon1 {
    static void Hieu(String x, String y){
        String res = "";
        int nho = 0;
        int n = x.length();
        int m = y.length();
        while(n > m){
            y = "0" + y;
            m++;
        }
        for(int i = n - 1; i >= 0; i--){
            int s = (int)x.charAt(i) - (int)y.charAt(i) - nho;
            if(s < 0){
                res = String.valueOf(s + 10) + res;
                nho = 1;
            }
            else{
                res = String.valueOf(s) + res;
                nho = 0;
            }
        }
        System.out.println(res);
    }
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        sc.nextLine();
        while(t > 0){
            t--;
            String x = sc.next();
            String y = sc.next();
            if(x.length() < y.length()){
                String tmp = x;
                x = y;
                y = tmp;
            }
            else if(x.length() == y.length() && x.compareTo(y) < 0){
                String tmp = x;
                x = y;
                y = tmp;
            }
            
            Hieu(x, y);
        }
    }
}
