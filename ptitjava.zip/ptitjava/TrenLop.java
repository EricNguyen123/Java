package main.java.com.mycompany.ptitjava;

import java.util.*;

public interface father {
    public abstract void word();
}

public interface mother {
    public abstract void cook();
}

class son implements father, mother {
    public void word() {
        System.out.println("father word");
    }

    public void cook() {
        System.out.println("mother cook");
    }

}

public class TrenLop {
    public static void main(String[] args) {
        son s = new son();
        s.cook();
        s.word();
    }

}
