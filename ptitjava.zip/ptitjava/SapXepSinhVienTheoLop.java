package main.java.com.mycompany.ptitjava;

import java.util.*;

class SinhVien {
    private String ID, Name, Lop, Email;

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        this.Name = name;
    }

    public String getLop() {
        return Lop;
    }

    public void setLop(String lop) {
        this.Lop = lop;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        this.Email = email;
    }

    public SinhVien(String id, String name, String lop, String email) {
        this.Name = name;
        this.Lop = lop;
        this.Email = email;
        this.ID = id;
    }
}

public class SapXepSinhVienTheoLop {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = Integer.parseInt(sc.nextLine());
        List<SinhVien> sinhVien = new ArrayList<>();

        while (t-- > 0) {
            sinhVien.add(new SinhVien(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine()));
        }
        Collections.sort(sinhVien, (SinhVien sinhVien1, SinhVien sinhVien2) -> {
            if (sinhVien1.getLop().compareTo(sinhVien2.getLop()) > 0) {
                return 1;
            } else if (sinhVien1.getLop().compareTo(sinhVien2.getLop()) < 0) {
                return -1;
            } else {
                if (sinhVien1.getID().compareTo(sinhVien2.getID()) > 0) {
                    return 1;
                } else {
                    return -1;
                }
            }
        });
        for (int i = 0; i < sinhVien.size(); i++) {
            System.out.println(sinhVien.get(i).getID() + " " + sinhVien.get(i).getName() + " "
                    + sinhVien.get(i).getLop() + " " + sinhVien.get(i).getEmail());
        }
    }
}
