/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.Scanner;
public class SoKhongLienKe {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        while(t > 0){
            t--;
            String s = sc.next();
            int m = s.length();
            int sum = 0;
            int d = 0;
            for(int i = 1; i < m; ++i){
                if((int)s.charAt(i - 1) + 2 == (int)s.charAt(i) || (int)s.charAt(i - 1) - 2 == (int)s.charAt(i)){
                    sum += (int)s.charAt(i - 1) - 48;
                }
                else{
                    d = 1;
                    break;
                }
            }
            if(d == 1){
                System.out.println("NO");
            }
            else{
                if((sum + (int)s.charAt(m - 1) - 48) % 10 == 0){
                    System.out.println("YES");
                }
                else{
                    System.out.println("NO");
                }
            }
        }
    }
}