/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.Scanner;
public class CatDoi {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        while(n > 0){
            n--;
            String s = sc.next();
            int m = s.length();
            long x = 0;
            int d = 0;
            for(int i = 0; i < m; i++){
                if(s.charAt(i) != '1' && (s.charAt(i) == '0' || s.charAt(i) == '8' || s.charAt(i) == '9')){
                    x = x * 10;
                }
                else if(s.charAt(i) == '1'){
                    x = x * 10 + 1;
                }
                else{
                    d = 1;
                    break;
                }
            }
            if(d == 0 && x != 0){
                System.out.println(x);
            }
            else{
                System.out.println("INVALID");
            }
        }
    }
}
