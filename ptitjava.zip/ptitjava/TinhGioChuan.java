package main.java.com.mycompany.ptitjava;

import java.io.*;
import java.util.*;

class GiangVien {
    private String id;
    private String name;
    private double soGio;

    public GiangVien(String id, String name) {
        this.id = id;
        this.name = name;
        this.soGio = 0;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void tinhSoGio(double t) {
        this.soGio += t;
    }

    public String toString() {
        return name + String.format("%.2f", soGio);
    }
}

class MonHoc {
    private String id;
    private String name;

    public MonHoc(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }
}

public class TinhGioChuan {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("MONHOC.in"));
        int n = Integer.parseInt(sc.nextLine());
        ArrayList<MonHoc> arrMon = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            String[] line = sc.nextLine().split("\\s+");
            arrMon.add(new MonHoc(line[0], line[1]));
        }
        sc = new Scanner(new File("GIANGVIEN.in"));
        n = Integer.parseInt(sc.nextLine());
        ArrayList<GiangVien> arrGV = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            String[] line = sc.nextLine().split("\\s+");
            String ten = "";
            for (int j = 1; j < line.length; j++) {
                ten += line[j] + " ";
            }
            arrGV.add(new GiangVien(line[0], ten));
        }
        sc = new Scanner(new File("GIOCHUAN.in"));
        n = Integer.parseInt(sc.nextLine());
        for (int i = 0; i < n; i++) {
            String[] line = sc.nextLine().split("\\s+");
            GiangVien gV = arrGV.stream().filter(gv -> gv.getId().equals(line[0])).findFirst().get();
            gV.tinhSoGio(Double.parseDouble(line[2]));
        }
        for (GiangVien gv : arrGV) {
            System.out.println(gv);
        }
        sc.close();
    }
}
