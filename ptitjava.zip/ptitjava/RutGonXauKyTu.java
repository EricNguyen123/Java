/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
public class RutGonXauKyTu {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String s = sc.next();
        while(true){
            int d = 0;
            for(int i = 0; i < s.length() - 1; i++){
                if(s.charAt(i + 1) == s.charAt(i)){
                    String x = "" + s.charAt(i) + s.charAt(i + 1);
                    s = s.replace(x, "");
                    d = 1;
                }
                
            }
            if(d == 0){
                break;
            }
        }
        if(s.equals("")){
            System.out.print("Empty String");
        }
        else{
            System.out.println(s);
        }
        
    }
}
