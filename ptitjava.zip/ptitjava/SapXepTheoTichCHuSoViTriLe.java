package main.java.com.mycompany.ptitjava;

import java.util.*;

public class SapXepTheoTichCHuSoViTriLe {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int t = scanner.nextInt();
        while (t-- > 0) {
            int n = scanner.nextInt();
            int[] a = new int[n];
            int[] b = new int[n];
            for (int i = 0; i < n; i++) {
                a[i] = scanner.nextInt();
                b[i] = 1;
                String x = String.valueOf(a[i]);
                for (int j = 0; j < x.length(); j++) {
                    if (j % 2 == 0) {
                        b[i] *= Integer.parseInt(String.valueOf(x.charAt(j)));
                    }
                }
            }
            for (int i = 0; i < n; i++) {
                for (int j = i + 1; j < n; j++) {
                    if (b[i] >= b[j]) {
                        int tg = a[i];
                        a[i] = a[j];
                        a[j] = tg;
                        tg = b[i];
                        b[i] = b[j];
                        b[j] = tg;
                    }
                }
            }
            for (int i = 0; i < n; i++) {
                System.out.print(a[i] + " ");
            }
            System.out.println();
        }
    }
}
