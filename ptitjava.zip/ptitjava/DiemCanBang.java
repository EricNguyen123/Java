/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
public class DiemCanBang {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        while(t > 0){
            t -= 1;
            int n = sc.nextInt();
            int[] a = new int[n];
            int x = 0;
            for(int i = 0; i < n; i++){
                a[i] = sc.nextInt();
                x += a[i];
                a[i] = x;
            }
            int d = 0;
            for(int i = 1; i < n; i++){
                if(a[i - 1] == x - a[i]){
                    d = 1;
                    System.out.println(i + 1);
                    break;
                }
            }
            if(d == 0){
                System.out.println(-1);
            }
            
        }
    }
}
