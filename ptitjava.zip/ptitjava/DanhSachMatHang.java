/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;

class Hang {
    String code, name, dv;
    long gmua, gban, ln;

    Hang(int code, String name, String dv, long gmua, long gban) {
        this.name = name;
        this.dv = dv;
        this.gmua = gmua;
        this.gban = gban;
        this.ln = gban - gmua;
        String x = String.valueOf(code);
        while (x.length() < 3) {
            x = "0" + x;
        }
        this.code = "MH" + x;
    }
}

public class DanhSachMatHang {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        Hang[] ds = new Hang[t];
        for (int i = 0; i < t; i++) {
            String x = sc.nextLine();
            String name = sc.nextLine(), dv = sc.nextLine();
            long gmua = sc.nextLong(), gban = sc.nextLong();
            ds[i] = new Hang(i + 1, name, dv, gmua, gban);
        }
        for (int i = 0; i < t - 1; i++) {
            for (int j = i + 1; j < t; j++) {
                if (ds[i].ln < ds[j].ln) {
                    Hang tmp = ds[i];
                    ds[i] = ds[j];
                    ds[j] = tmp;
                } else if (ds[i].ln == ds[j].ln) {
                    if (ds[i].code.compareTo(ds[j].code) > 0) {
                        Hang tmp = ds[i];
                        ds[i] = ds[j];
                        ds[j] = tmp;
                    }
                }
            }
        }
        for (int i = 0; i < t; i++) {
            System.out.println(ds[i].code + " " + ds[i].name + " " + ds[i].dv + " " + ds[i].gmua + " " + ds[i].gban
                    + " " + ds[i].ln);
        }
    }
}
