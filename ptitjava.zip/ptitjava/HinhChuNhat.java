package com.mycompany.ptitjava;
import java.util.Scanner;
public class HinhChuNhat {

    
    public static void main(String args[]) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
//        System.out.println("Nhap:");
        int a = sc.nextInt();
        int b = sc.nextInt();
//        int a = 10;
//        int b = 2;
        long c = a * b;
        long d = (a + b) * 2;
        System.out.print(d);
        System.out.print(" ");
        System.out.print(c);
    }
}
