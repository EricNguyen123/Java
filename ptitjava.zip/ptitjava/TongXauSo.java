package main.java.com.mycompany.ptitjava;

public interface TongXauSo {
    public void CongXauSo();
}
