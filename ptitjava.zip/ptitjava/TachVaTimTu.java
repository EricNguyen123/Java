package main.java.com.mycompany.ptitjava;

import java.util.*;

public class TachVaTimTu {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int t = Integer.parseInt(scanner.nextLine());
        while (t-- > 0) {
            String a = scanner.nextLine().toUpperCase().trim();
            String[] b = scanner.nextLine().split("\\s+");
            for (int i = 0; i < b.length; i++) {
                if (a.contains(b[i].toUpperCase())) {
                    System.out.print(b[i] + " ");
                }
            }
        }
    }
}
