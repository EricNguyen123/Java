/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.Scanner;
public class KiemTraSoFibonacci {
    public static int KiemTra(long a, long[] b){
        int l = 0;
        int r = b.length - 1;
        while(l <= r){
            int mid = (l + r) / 2;
            if(b[mid] == a){
                return 1;
            }
            else if(b[mid] > a){
                r = mid - 1;
            }
            else{
                l = mid + 1;
            }
        }
        return 0;
    }
    public static void main(String args[]){
        long[] fibonacci = new long[93];
        fibonacci[0] = 0;
        fibonacci[1] = fibonacci[2] = 1;
        for(int i = 3; i <= 92; i++){
            fibonacci[i] = fibonacci[i - 2] + fibonacci[i - 1];
        }
        
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        while(n > 0){
            n--;
            long m = sc.nextLong();
            if(KiemTra(m, fibonacci) == 1){
                System.out.println("YES");
            }
            else{
                System.out.println("NO");
            }
        }
    }
}
