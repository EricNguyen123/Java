package main.java.com.mycompany.ptitjava;

import java.util.*;

class DoanhNghiep {
    private String ID, Name, Sluong;

    public String getID() {
        return ID;
    }

    public String getName() {
        return Name;
    }

    public String getSluong() {
        return Sluong;
    }

    public DoanhNghiep(String ID, String Name, String Sluong) {
        this.ID = ID;
        this.Name = Name;
        this.Sluong = Sluong;
    }

    @Override
    public String toString() {
        return this.ID + " " + this.Name + " " + this.Sluong;
    }
}

public class DanhSachDoanhNghiepNhanSinhVienThucTap2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int t = Integer.parseInt(scanner.nextLine());
        List<DoanhNghiep> doanhNghiep = new ArrayList<>();
        while (t-- > 0) {
            doanhNghiep.add(new DoanhNghiep(scanner.nextLine(), scanner.nextLine(), scanner.nextLine()));
        }
        int q = Integer.parseInt(scanner.nextLine());

        Collections.sort(doanhNghiep, new Comparator<DoanhNghiep>() {
            @Override
            public int compare(DoanhNghiep o1, DoanhNghiep o2) {
                if (Integer.parseInt(o1.getSluong() == Integer.parseInt(o2.getSluong()))) {
                    return o1.getID().compareTo(o2.getID());
                }
                return Integer.parseInt(o1.getSluong()) > Integer.parseInt(o2.getSluong()) ? -1 : 1;
            }
        });

        while (q-- > 0) {
            int a = scanner.nextInt();
            int b = scanner.nextInt();
            System.out.println("DANH SACH DOANH NGHIEP NHAN TU " + a + " DEN " + b + " SINH VIEN:");
            // List<DoanhNghiep>x = new ArrayList<DoanhNghiep>();
            for (DoanhNghiep i : doanhNghiep) {
                if (Integer.parseInt(i.getSluong()) >= a && Integer.parseInt(i.getSluong()) <= b) {
                    System.out.println(i);
                }
            }

        }
    }
}
