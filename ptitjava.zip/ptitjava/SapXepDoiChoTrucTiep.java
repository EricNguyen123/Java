/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;

public class SapXepDoiChoTrucTiep {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] a = new int[n];
        int[] b = new int[n];
        for(int i = 0 ; i < n; i++){
            a[i] = sc.nextInt();
            b[i] = a[i];
        }
        Arrays.sort(a);
        for(int i = 0; i < n - 1; i++){
            for(int j = i + 1; j < n; j++){
                if(b[i] > b[j]){
                    int tg = b[i];
                    b[i] = b[j];
                    b[j] = tg;
                }
            }
            int d = 0;
            for(int j = 0; j < n; j++){
                if(a[j] != b[j]){
                    d = 1;
                    break;
                }
            }
            
            System.out.print("Buoc " + (i + 1) + ":");
            for(int j = 0; j < n; j++){
                System.out.print(" " + b[j]);
            }
            System.out.println();
            if(d == 0){
                break;
            }
        }
    }
}
