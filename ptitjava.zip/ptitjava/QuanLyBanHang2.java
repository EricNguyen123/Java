package main.java.com.mycompany.ptitjava;

import java.util.*;
import java.io.*;
import java.lang.*;

class KhachHang {
    private String MaKH, NameKH, GioiTinh, NgaySinh, DiaChi;

    public String getNameKH() {
        return NameKH;
    }

    public String getMaKH() {
        return MaKH;
    }

    public String getGioiTinh() {
        return GioiTinh;
    }

    public String getNgaySinh() {
        return NgaySinh;
    }

    public String getDiaChi() {
        return DiaChi;
    }

    public void setMaKH(String MaKH) {
        this.MaKH = MaKH;
    }

    public void setNameKH(String NameKH) {
        this.NameKH = NameKH;
    }

    public void setGioiTinh(String GioiTinh) {
        this.GioiTinh = GioiTinh;
    }

    public void setNgaySinh(String NgaySinh) {
        this.NgaySinh = NgaySinh;
    }

    public void setDiaChi(String DiaChi) {
        this.DiaChi = DiaChi;
    }

    public KhachHang(int IDKH, String NameKH, String GioiTinh, String NgaySinh, String DiaChi) {
        this.MaKH = String.format("KH%03d", IDKH);
        this.NameKH = NameKH;
        this.GioiTinh = GioiTinh;
        String[] a = NgaySinh.split("/");
        while (a[0].length() < 2) {
            a[0] = "0" + a[0];
        }
        while (a[1].length() < 2) {
            a[1] = "0" + a[1];
        }
        while (a[2].length() < 4) {
            a[2] = "0" + a[2];
        }
        this.NgaySinh = a[0] + "/" + a[1] + "/" + a[2];
        this.DiaChi = DiaChi;
    }
}

class MatHang {
    private String MaMH, NameMH, DonVi;
    private long GiaMua, GiaBan;

    public String getMaMH() {
        return MaMH;
    }

    public String getNameMH() {
        return NameMH;
    }

    public String getDonVi() {
        return DonVi;
    }

    public long getGiaMua() {
        return GiaMua;
    }

    public long getGiaBan() {
        return GiaBan;
    }

    public void setMaMH(String MaMH) {
        this.MaMH = MaMH;
    }

    public void setNameMH(String NameMH) {
        this.NameMH = NameMH;
    }

    public void setDonVi(String DonVi) {
        this.DonVi = DonVi;
    }

    public void setGiaMua(long GiaMua) {
        this.GiaMua = GiaMua;
    }

    public void setGiaBan(long GiaBan) {
        this.GiaBan = GiaBan;
    }

    public MatHang(int MaMH, String NameMH, String DonVi, long GiaMua, long GiaBan) {
        this.MaMH = String.format("MH%03d", MaMH);
        this.NameMH = NameMH;
        this.DonVi = DonVi;
        this.GiaMua = GiaMua;
        this.GiaBan = GiaBan;
    }
}

class HoaDon {
    private String MaHD;
    private KhachHang KH;
    private MatHang MH;
    private long SoLuong, LoiNhuan;

    public String getMaHD() {
        return MaHD;
    }

    public KhachHang getKH() {
        return KH;
    }

    public MatHang getMH() {
        return MH;
    }

    public long getSoLuong() {
        return SoLuong;
    }

    public long getLoiNhuan() {
        return LoiNhuan;
    }

    public void setMaHD(String MaHD) {
        this.MaHD = MaHD;
    }

    public void setKH(KhachHang KH) {
        this.KH = KH;
    }

    public void setMH(MatHang MH) {
        this.MH = MH;
    }

    public void setSoLuong(long SoLuong) {
        this.SoLuong = SoLuong;
    }

    public void setLoiNhuan(long LoiNhuan) {
        this.LoiNhuan = LoiNhuan;
    }

    public HoaDon(int MaHD, KhachHang KH, MatHang MH, long SoLuong) {
        this.MaHD = String.format("HD%03d", MaHD);
        this.KH = KH;
        this.MH = MH;
        this.SoLuong = SoLuong;
        this.LoiNhuan = SoLuong * MH.getGiaBan() - SoLuong * MH.getGiaMua();
    }

    @Override
    public String toString() {
        return this.MaHD + " " + this.KH.getNameKH() + " " + this.KH.getDiaChi() + " " + this.MH.getNameMH() + " "
                + this.SoLuong + " " + this.SoLuong * this.MH.getGiaBan() + " " + this.LoiNhuan;
    }
}

public class QuanLyBanHang2 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int n = Integer.parseInt(scan.nextLine());
        List<KhachHang> kh = new ArrayList<KhachHang>();
        for (int i = 0; i < n; i++) {
            kh.add(new KhachHang(i + 1, scan.nextLine(), scan.nextLine(), scan.nextLine(),
                    scan.nextLine()));
        }
        int m = Integer.parseInt(scan.nextLine());
        List<MatHang> mh = new ArrayList<MatHang>();
        for (int i = 0; i < m; i++) {
            mh.add(new MatHang(i + 1, scan.nextLine(), scan.nextLine(), Long.parseLong(scan.nextLine()),
                    Long.parseLong(scan.nextLine())));
        }
        int k = scan.nextInt();
        scan.nextLine();
        List<HoaDon> hd = new ArrayList<HoaDon>();
        for (int i = 0; i < k; i++) {
            String[] sc = scan.nextLine().trim().split("\\s+");
            String makh = sc[0], mamh = sc[1], soluong = sc[2];
            KhachHang KH = kh.stream().filter(s -> s.getMaKH().equals(makh)).findFirst().get();
            MatHang MH = mh.stream().filter(s -> s.getMaMH().equals(mamh)).findFirst().get();
            hd.add(new HoaDon(i + 1, KH, MH, Long.parseLong(soluong)));
        }
        Collections.sort(hd, new Comparator<HoaDon>() {
            @Override
            public int compare(HoaDon o1, HoaDon o2) {
                return o1.getLoiNhuan() > o2.getLoiNhuan() ? -1 : 1;
            }
        });
        for (int i = 0; i < hd.size(); i++) {
            System.out.println(hd.get(i));
        }
        scan.close();
    }
}
