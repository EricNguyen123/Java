/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;

class Email{
    String name;
    int stt;
    String mail;
    Email(String name){
        this.name = name;
        String[] x = this.name.split(" ");
        this.mail = "";
        for(int i = 0; i < x.length - 1; i++){
            this.mail += String.valueOf(x[i].charAt(0));
        }
        this.mail = x[x.length - 1] + this.mail;
    }
    
}

class ListMail{
    Email[] x;
    ListMail(Email[] x){
        this.x = x;
        for(int i = 0; i < this.x.length; i++){
            int b = 0;
            for(int j = i - 1; j >= 0; j--){
                if(x[i].mail.compareTo(x[j].mail) == 0){
                    x[i].stt = x[j].stt + 1;
                    b = 1;
                    break;
                }
            }
            if(b == 0){
                x[i].stt = 1;
            }
        }
        for(int i = 0; i < this.x.length; i++){
            if(x[i].stt != 1){
                x[i].mail += String.valueOf(x[i].stt) + "@ptit.edu.vn";
            }
            else{
                x[i].mail +=  "@ptit.edu.vn";
            }
        }
    }
    void In(){
        for (Email x1 : this.x) {
            System.out.println(x1.mail);
        }
    }

}



public class DiaChiEmail {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        Email[] a = new Email[t];
        sc.nextLine();
        String[] s = new String[t];
        for(int i = 0; i < t; i++){   
            String name = sc.nextLine();
            name = name.trim().toLowerCase();
            name = name.replaceAll("\\s+", " ");
            s[i] = name;
        }
//        System.out.println(s.length);
        for(int i = 0; i < t; i++){
            a[i] = new Email(s[i]);
//            System.out.println(s[i]);
        }
        ListMail res = new ListMail(a);
        res.In();
    }
}
