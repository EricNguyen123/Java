
package com.mycompany.ptitjava;

import java.util.*;

class Customer{
    String address, code, name;
    Customer (String address, String code, String name){
        this.address = address;
        this.code = code;
        this.name = name;
    }
    
}
class OrderList{
    Vector<Order> orderList = new Vector<>();
    void add(Order order){
        this.orderList.add(order);
    }
    void remove(Order order){
        this.orderList.remove(order);
    }
}
class OrderLine{
    double value;
    OrderLine (double value){
        this.value = value;
    }
}
class Order{
    Customer customer;
    Vector<OrderLine> orderLine = new Vector<>();
    double total;
    Order(Customer x){
        this.customer = x;
    }
    void addLine(OrderLine orderLine){
       this.orderLine.add(orderLine);
    }
    void removeLine(OrderLine orderLine){
        this.orderLine.remove(orderLine);
    }
    
}
public class QuanLyDonHang {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        while(true){
            Order order;
            String address = sc.nextLine();
            if("0".equals(address)){
                break;
            }
            String code = sc.next();
            String name = sc.nextLine();
            order =new Order(new Customer(address, code, name));
           
            while(true){
                double gia = sc.nextDouble();
                if(gia == -1){
                    break;
                }
                OrderLine y = new OrderLine(gia);
                order.addLine(y);
            }
            System.out.print(order.customer.address);
            System.out.print(" " + order.customer.code);
            System.out.print(" " + order.customer.name + " "); 
            for(int i = 0; i < order.orderLine.size(); i++){
                System.out.print(order.orderLine.get(i).value + " ");
            }
            OrderList x = new OrderList();
            x.add(order);
            System.out.println();
        }
    }
}
