package main.java.com.mycompany.ptitjava;

import java.util.Scanner;
import java.util.Collections;
import java.util.HashMap;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;

class Subject {
    private String id;
    private String name;
    private String type;

    public Subject(String id, String name, String type) {
        this.id = id;
        this.name = name;
        this.type = type;
    }

    public String toString() {
        return name;
    }
}

class Test implements Comparable<Test> {
    private String id;
    private String date;
    private String time;
    private String code;

    public Test(String id, String date, String time, String code) {
        this.id = id;
        this.date = date;
        this.time = time;
        this.code = code;
    }

    public String getDate_Time() {
        return date + " " + time;
    }

    public String getId() {
        return id;
    }

    public int compareTo(Test t) {
        if (this.getDate_Time().equals(t.getDate_Time())) {
            return this.getId().compareTo(t.getId());
        }
        return this.getDate_Time().compareTo(t.getDate_Time());
    }

    public String toString() {
        return date + " " + time + " " + code;
    }
}

class TestSchedule implements Comparable<TestSchedule> {
    private Test test;
    private Subject sub;
    private String codeGr;
    private int number;

    public TestSchedule(Test test, Subject sub, String codeGr, int number) {
        this.test = test;
        this.sub = sub;
        this.codeGr = codeGr;
        this.number = number;
    }

    public Test getTest() {
        return test;
    }

    public int compareTo(TestSchedule o) {
        if (this.getTest().getDate_Time().equals(o.getTest().getDate_Time())) {
            return this.getTest().getId().compareTo(o.getTest().getId());
        }
        return this.getTest().getDate_Time().compareTo(o.getTest().getDate_Time());
    }

    public String toString() {
        return test + " " + sub + " " + codeGr + " " + number;
    }
}

public class SapXepLichThi {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(new File("MONTHI.in"));
        int n = Integer.parseInt(sc.nextLine());
        HashMap<String, Subject> subHs = new HashMap<>();
        for (int i = 0; i < n; i++) {
            String id = sc.nextLine();
            Subject sub = new Subject(id, sc.nextLine(), sc.nextLine());
            subHs.put(id, sub);
        }
        sc = new Scanner(new File("CATHI.in"));
        int m = Integer.parseInt(sc.nextLine());
        HashMap<String, Test> testHs = new HashMap<>();
        for (int i = 0; i < m; i++) {
            String id = String.format("C%03d", i + 1);
            Test test = new Test(id, sc.nextLine(), sc.nextLine(), sc.nextLine());
            testHs.put(id, test);
        }
        sc = new Scanner(new File("LICHTHI.in"));
        int t = Integer.parseInt(sc.nextLine());
        ArrayList<TestSchedule> arr = new ArrayList<>();
        for (int i = 0; i < t; i++) {
            String[] line = sc.nextLine().split("\\s+");
            Test test = testHs.get(line[0]);
            Subject sub = subHs.get(line[1]);
            TestSchedule ts = new TestSchedule(test, sub, line[2], Integer.parseInt(line[3]));
            arr.add(ts);
        }
        Collections.sort(arr);
        for (TestSchedule ts : arr) {
            System.out.println(ts);
        }
        sc.close();
    }
}