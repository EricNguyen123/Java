package main.java.com.mycompany.ptitjava;

import java.util.*;

class ThiSinh {
    private String code, name, check;
    private double a, b, c, d, e;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getA() {
        return a;
    }

    public void setA(float a) {
        this.a = a;
    }

    public double getB() {
        return b;
    }

    public void setB(float b) {
        this.b = b;
    }

    public double getC() {
        return c;
    }

    public void setC(float c) {
        this.c = c;
    }

    public double getD() {
        return d;
    }

    public void setD(float d) {
        this.d = d;
    }

    public double getE() {
        return e;
    }

    public void setE(float e) {
        this.e = e;
    }

    public String getCheck() {
        return check;
    }

    public void setCheck(String check) {
        this.check = check;
    }

    public ThiSinh(String code, String name, double a, double b, double c) {
        this.code = code;
        this.name = name;
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = a * 2 + b + c;
        String kv = this.code.substring(0, 3);
        if (kv.equals("KV1")) {
            this.e = 0.5;

        } else if (kv.equals("KV2")) {
            this.e = 1;

        } else if (kv.equals("KV3")) {
            this.e = 2.5;

        }
        if (this.d + this.e < 24) {
            this.check = "TRUOT";
        } else {
            this.check = "TRUNG TUYEN";
        }
    }
}

public class BaiToanTuyenSinh {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String code, name;
        double a, b, c;
        code = scanner.nextLine();
        name = scanner.nextLine();
        a = scanner.nextDouble();
        b = scanner.nextDouble();
        c = scanner.nextDouble();
        ThiSinh ts = new ThiSinh(code, name, a, b, c);
        System.out.print(ts.getCode() + " " + ts.getName() + " ");
        if (ts.getE() != (int) ts.getE()) {
            System.out.printf("%.1f", ts.getE());
        } else {
            System.out.print((int) ts.getE());
        }
        System.out.print(" ");
        if (ts.getD() != (int) ts.getD()) {
            System.out.printf("%.1f", ts.getD());
        } else {
            System.out.print((int) ts.getD());
        }
        System.out.print(" " + ts.getCheck());
        System.out.println();
    }

}
