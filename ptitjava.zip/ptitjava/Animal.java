package main.java.com.mycompany.ptitjava;

public interface Animal {
    void makeSound();
}
