package main.java.com.mycompany.ptitjava;

public class Cow implements Animal {
    public void makeSound() {
        System.out.println("The sound a cow makes is moo!");
    }

    public static void main(String[] args) {
        Cow cow = new Cow();
        cow.makeSound();
    }
}
