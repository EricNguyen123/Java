package main.java.com.mycompany.ptitjava;

import java.util.*;

class BTL {
    private int STTN;
    private String TBTL;

    public String getTBTL() {
        return TBTL;
    }

    public void setTBTL(String TBTL) {
        this.TBTL = TBTL;
    }

    public int getSTTN() {
        return STTN;
    }

    public void setSTTN(int STTN) {
        this.STTN = STTN;
    }

    public BTL(int STTN, String TBTL) {
        this.STTN = STTN;
        this.TBTL = TBTL;
    }
}

class SinhVien {
    private String ID, Name, SDT;
    private int STTN;

    public String getID() {
        return ID;
    }

    public String getName() {
        return Name;
    }

    public String getSDT() {
        return SDT;
    }

    public int getSTTN() {
        return STTN;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public void setSDT(String SDT) {
        this.SDT = SDT;
    }

    public void setSTTN(int STTN) {
        this.STTN = STTN;
    }

    public SinhVien(String ID, String Name, String SDT, int STTN) {
        this.ID = ID;
        this.Name = Name;
        this.SDT = SDT;
        this.STTN = STTN;
    }
}

public class QuanLyBaiTapNhom2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int m = sc.nextInt();
        List<SinhVien> sinhVien = new ArrayList<SinhVien>();
        for (int i = 0; i < n; i++) {
            sc.nextLine();
            String ID = sc.nextLine();
            String Name = sc.nextLine();
            String SDT = sc.nextLine();
            int STTN = sc.nextInt();
            sinhVien.add(new SinhVien(ID, Name, SDT, STTN));
        }
        sc.nextLine();
        List<BTL> btl = new ArrayList<BTL>();
        for (int i = 0; i < m; i++) {
            btl.add(new BTL(i + 1, sc.nextLine()));
        }
        Collections.sort(sinhVien, new Comparator<SinhVien>() {
            @Override
            public int compare(SinhVien o1, SinhVien o2) {
                if (o1.getID().compareTo(o2.getID()) > 0)
                    return 1;
                else if (o1.getID().compareTo(o2.getID()) < 0)
                    return -1;
                return 0;
            }
        });
        for (int i = 0; i < n; i++) {
            System.out.println(sinhVien.get(i).getID() + " " + sinhVien.get(i).getName() + " "
                    + sinhVien.get(i).getSDT() + " " + sinhVien.get(i).getSTTN() + " "
                    + btl.get(sinhVien.get(i).getSTTN() - 1).getTBTL());
        }
    }
}
