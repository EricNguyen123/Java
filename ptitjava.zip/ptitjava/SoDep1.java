/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
public class SoDep1 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        while(n > 0){
            n--;
            String x = sc.next();
            int i = 0;
            int d = 0;
            while(true){
                if(i == x.length()){
                    break;
                }
                if(((int)x.charAt(i) - 48) % 2 != 0){
                    d = 1;
                    System.out.println("NO");
                    break;
                }
                i++;
            }
            if(d == 0){
                System.out.println("YES");
            }
        }
    }
}
