package main.java.com.mycompany.ptitjava;

import java.util.*;

class Point {
    private double x, y;

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double getDist(Point A) {
        return Math.sqrt((this.x - A.x) * (this.x - A.x) + (this.y - A.y) * (this.y - A.y));
    }
}
class Triangle
{
    private Point A = new Point(), B = new Point(), C = new Point();
    private double AB, AC, BC;

    Triangle(double x1, double y1, double x2, double y2, double x3, double y3)
    {
        A.setX(x1);
        A.setY(y1);
        B.setX(x2);
        B.setY(y2);
        C.setX(x3);
        C.setY(y3);
        this.AB = A.getDist(B);
        this.AC = A.getDist(C);
        this.BC = B.getDist(C);
    }

    @Override
    public String toString()
    {
        if (AB + AC <= BC || AC + BC <= AB || AB + BC <= AC)
            return String.format("INVALID");
        double p = (AB + AC + BC) / 2.0;
        return String.format("%.2f", Math.sqrt(p * (p - AB) * (p - AC) * (p - BC)));
    }
}
public class DienTichTamGiac
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        while (t-- > 0)
        {
            Triangle A = new Triangle(sc.nextDouble(), sc.nextDouble(), sc.nextDouble(), sc.nextDouble(), sc.nextDouble(), sc.nextDouble());
            System.out.println(A);
        }
    }
}