/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
public class BoSungSoConThieu {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] a = new int[n];
        for(int i = 0; i < n; i++){
            a[i] = sc.nextInt();
        }
        if(a[0] == 1 && a[n - 1] - a[0] + 1 == n){
            System.out.println("Excellent!");
        }
        else{
            for(int i = 1; i < a[0]; i++){
                System.out.println(i);
            }
            for(int i = 0; i < n - 1; i++){
                while(a[i] + 1 != a[i + 1]){
                    a[i]++;
                    System.out.println(a[i]);
                }
            }
        }
    }
}
