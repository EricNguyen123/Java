/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
public class ChuanHoaXauHoTen2 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        String v = sc.nextLine();
        for(int i = 0; i < n; i++){
            
            String s = sc.nextLine();
            s = s.trim().toLowerCase();
            s = s.replaceAll("\\s+", " ");
            String res = "";
            String[] tmp = s.split(" ");
            int x = 0;
            for (int j = 1; j < tmp.length; j++) {
                res += String.valueOf(tmp[j].charAt(0)).toUpperCase() + tmp[j].substring(1);
                if(j < tmp.length - 1){
                    res += " ";
                }
            }
            res += ", " + tmp[0].toUpperCase();
            res = res.trim();
            System.out.println(res);
        }
    }
}
