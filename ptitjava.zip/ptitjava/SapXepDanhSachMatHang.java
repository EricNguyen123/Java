package main.java.com.mycompany.ptitjava;

import java.util.*;

class Hang {
    private int ma;
    private String name;
    private String loaihang;
    private float gban;
    private float gmua;
    private float lnhuan;

    public int getma() {
        return ma;
    }

    public void setma(int ma) {
        this.ma = ma;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLoaihang() {
        return loaihang;
    }

    public void setLoaihang(String loaihang) {
        this.loaihang = loaihang;
    }

    public float getGban() {
        return gban;
    }

    public void setGban(float gban) {
        this.gban = gban;
    }

    public float getGmua() {
        return gmua;
    }

    public void setGmua(float gmua) {
        this.gmua = gmua;
    }

    public float getLnhuan() {
        return lnhuan;
    }

    public void setLnhuan(float lnhuan) {
        this.lnhuan = lnhuan;
    }

    public Hang(int ma, String name, String loaihang, float gmua, float gban) {
        this.ma = ma;
        this.name = name;
        this.loaihang = loaihang;
        this.gban = gban;
        this.gmua = gmua;
        this.lnhuan = gban - gmua;
    }
}

public class SapXepDanhSachMatHang {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        int i = 1;
        List<Hang> hs = new ArrayList<Hang>();
        while (t-- > 0) {
            int ma = i;
            sc.nextLine();
            String name = sc.nextLine();
            String loaihang = sc.nextLine();

            float gmua = sc.nextFloat();
            float gban = sc.nextFloat();
            i++;
            hs.add(new Hang(ma, name, loaihang, gmua, gban));
        }
        Collections.sort(hs, new Comparator<Hang>() {
            @Override
            public int compare(Hang h1, Hang h2) {
                return h1.getLnhuan() > h2.getLnhuan() ? -1 : 1;
            }
        });
        for (Hang h : hs) {
            System.out.print(h.getma() + " " + h.getName() + " " + h.getLoaihang() + " ");
            System.out.printf("%.2f", h.getLnhuan());
            System.out.println();
        }
    }

}
