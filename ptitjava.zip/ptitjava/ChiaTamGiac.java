/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
public class ChiaTamGiac {
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        double n, h;
        while(t-- > 0)
        {
            n = sc.nextDouble();
            h = sc.nextDouble();
            for(int i = 1; i < n; ++i)
                System.out.printf("%.6f ", h * Math.sqrt(i / n));
            System.out.println();
        }
    }
}
