package main.java.com.mycompany.ptitjava;
import java.io.*;
import java.util.*;

public class LietKeTheoThuTuXuatHien {

    public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream("NHIPHAN.in"));
        List<String> l = (ArrayList<String>) ois.readObject();
        Set<String> s = new TreeSet<>();
        for (String i : l) {
            String[] words = i.trim().toLowerCase().split("\\s+");
            s.addAll(Arrays.asList(words));
        }
        Scanner sc = new Scanner(new File("VANBAN.in"));
        while (sc.hasNext()) {
            String x = sc.next().toLowerCase();
            if (s.contains(x)) {
                System.out.println(x);
                s.remove(x);
            }
        }
    }
}