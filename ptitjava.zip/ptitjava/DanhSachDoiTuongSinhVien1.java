package com.mycompany.ptitjava;

import java.util.*;
import java.lang.*;

class SinhVien {
    private String ID, Name, Date, Lop;
    private float GPA;

    public String getID() {
        return this.ID;
    }

    public void setID(String iD) {
        ID = iD;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getLop() {
        return Lop;
    }

    public void setLop(String class1) {
        Lop = class1;
    }

    public float getGPA() {
        return GPA;
    }

    public void setGPA(float gPA) {
        GPA = gPA;
    }

    public SinhVien(String name, String date, String lop, int iD, float gPA) {
        this.Name = name;
        this.GPA = (float) Math.round(gPA * 100) / 100;
        String[] a = new String[3];
        a = date.split("/");
        while (a[0].length() < 2) {
            a[0] = "0" + a[0];
        }
        while (a[1].length() < 2) {
            a[1] = "0" + a[1];
        }

        this.Date = a[0] + "/" + a[1] + "/" + a[2];
        this.Lop = lop;
        String id = String.valueOf(iD);
        while (id.length() < 3) {
            id = "0" + id;
        }
        this.ID = "B20DCCN" + id;
    }

}

public class DanhSachDoiTuongSinhVien1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Vector<SinhVien> sinhVien = new Vector<>();
        int t = sc.nextInt();
        int i = 1;

        while (t > 0) {
            sc.nextLine();
            String name = sc.nextLine();

            String lop = sc.next();
            String date = sc.next();
            int iD = i;
            float gPA = sc.nextFloat();
            SinhVien sv = new SinhVien(name, date, lop, iD, gPA);
            sinhVien.add(sv);
            t--;
            i++;
        }
        for (SinhVien sv : sinhVien) {
            System.out.print(
                    sv.getID() + " " + sv.getName() + " " + sv.getLop() + " " + sv.getDate() + " ");
            System.out.printf("%.2f", sv.getGPA());
            System.out.println();
        }
    }
}