package main.java.com.mycompany.ptitjava;

import java.util.*;

class Time {
    int gio, phut, giay;

    Time(int gio, int phut, int giay) {
        this.gio = gio;
        this.phut = phut;
        this.giay = giay;
    }
}

public class SapXepThoiGian {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        List<Time> timeList = new ArrayList<Time>();
        for (int i = 0; i < n; i++) {
            int gio = sc.nextInt();
            int phut = sc.nextInt();
            int giay = sc.nextInt();
            timeList.add(new Time(gio, phut, giay));
        }
        Collections.sort(timeList, new Comparator<Time>() {
            @Override
            public int compare(Time t1, Time t2) {
                if (t1.gio > t2.gio) {
                    return 1;
                } else if (t1.gio < t2.gio) {
                    return -1;
                } else {
                    if (t1.phut > t2.phut) {
                        return 1;
                    } else if (t1.phut < t2.phut) {
                        return -1;
                    } else {
                        if (t1.giay > t2.giay) {
                            return 1;
                        } else if (t1.giay < t2.giay) {
                            return -1;
                        }
                    }
                }
                return 0;
            }
        });
        for (int i = 0; i < timeList.size(); i++) {
            System.out.println(timeList.get(i).gio + " " + timeList.get(i).phut + " " + timeList.get(i).giay);
        }
    }
}
