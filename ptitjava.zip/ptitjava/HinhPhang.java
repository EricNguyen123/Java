package main.java.com.mycompany.ptitjava;

public abstract class HinhPhang {
    public abstract long ChuVi();

    public abstract long DienTich();
}
