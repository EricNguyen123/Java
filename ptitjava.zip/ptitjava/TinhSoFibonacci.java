/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.Scanner;
public class TinhSoFibonacci {
    
    public static void main(String args[]){
        long[] fibonacci = new long[93];
        fibonacci[0] = 0;
        fibonacci[1] = fibonacci[2] = 1;
        for(int i = 3; i <= 92; i++){
            fibonacci[i] = fibonacci[i - 2] + fibonacci[i - 1];
        }
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        while(n > 0){
            n--;
            int m = sc.nextInt();
            System.out.println(fibonacci[m]);
        }
    }
}
