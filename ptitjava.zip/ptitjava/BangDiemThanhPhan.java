package main.java.com.mycompany.ptitjava;

import java.util.*;

class SinhVien {
    private String ID, Name, Lop, Diem1, Diem2, Diem3;

    public String getID() {
        return ID;
    }

    public String getName() {
        return Name;
    }

    public String getLop() {
        return Lop;
    }

    public String getDiem1() {
        return Diem1;
    }

    public String getDiem2() {
        return Diem2;
    }

    public String getDiem3() {
        return Diem3;
    }

    public SinhVien(String ID, String Name, String Lop, String Diem1, String Diem2, String Diem3) {
        this.ID = ID;
        this.Name = Name;
        this.Lop = Lop;
        this.Diem1 = Diem1;
        this.Diem2 = Diem2;
        this.Diem3 = Diem3;
    }

    @Override
    public String toString() {
        return ID + " " + Name + " " + Lop + " " + Diem1 + " " + Diem2 + " " + Diem3;
    }
}

public class BangDiemThanhPhan {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int t = Integer.parseInt(scanner.nextLine());
        List<SinhVien> sinhVien = new ArrayList<>();
        for (int i = 0; i < t; i++) {
            sinhVien.add(new SinhVien(scanner.nextLine(), scanner.nextLine(), scanner.nextLine(),
                    scanner.nextLine(), scanner.nextLine(), scanner.nextLine()));
        }
        Collections.sort(sinhVien, new Comparator<SinhVien>() {
            @Override
            public int compare(SinhVien o1, SinhVien o2) {
                return o1.getName().compareTo(o2.getName());
            }
        });
        for (int i = 0; i < t; i++) {
            System.out.print((i + 1) + " ");
            System.out.println(sinhVien.get(i));
        }
    }
}
