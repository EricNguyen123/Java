/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.Scanner;
public class BoiChungUocChung {
    public static long UCLN(long a, long b){
        if(a < b){
            long tmp = a;
            a = b;
            b = tmp;
        }
        while(b != 0){
            long tmp = a % b;
            a = b;
            b = tmp;
        }
        return a;
    }
    public static long BCNN(long a, long b, long gcd){
        return a * b / gcd;
    }
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        while(n > 0){
            n--;
            long a, b;
            a = sc.nextLong();
            b = sc.nextLong();
            long ucln = UCLN(a, b);
            long bcnn = BCNN(a, b, ucln);
            System.out.println(bcnn + " " + ucln);
            
        }
    }
}
