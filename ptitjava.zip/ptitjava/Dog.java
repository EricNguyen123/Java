package main.java.com.mycompany.ptitjava;

public class Dog implements Animal {
    public void makeSound() {
        System.out.println("The sound a dog makes woof woof!");
    }

    public static void main(String[] args) {
        Dog dog = new Dog();
        dog.makeSound();
    }
}
