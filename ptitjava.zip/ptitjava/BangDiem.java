package main.java.com.mycompany.ptitjava;

import java.util.*;

class HocSinh {
    private String code, name, danhHieu;
    private float[] a = new float[10];
    private float diemTB;

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public String getDanhHieu() {
        return danhHieu;
    }

    public float getDiemTB() {
        return diemTB;
    }

    HocSinh(int code, String name, float[] a) {
        this.code = String.format("HS%02d", code);
        this.name = name;
        int x = 0;
        for (int i = 0; i < 10; i++) {
            this.a[i] = a[i];
            x += a[i];
        }
        this.diemTB = Math.round(x * 10) / 10;
        if (this.diemTB >= 9) {
            this.danhHieu = "XUAT SAC";
        } else if (this.diemTB >= 8 && this.diemTB < 9) {
            this.danhHieu = "GIOI";
        } else if (this.diemTB >= 7 && this.diemTB < 8) {
            this.danhHieu = "KHA";
        } else if (this.diemTB >= 5 && this.diemTB < 7) {
            this.danhHieu = "TB";
        } else {
            this.danhHieu = "YEU";
        }
    }

    @Override
    public String toString() {
        return this.code + " " + this.name + " " + this.diemTB + " " + this.danhHieu;
    }
}

public class BangDiem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = Integer.parseInt(sc.nextLine());
        Vector<HocSinh> a = new Vector<HocSinh>();
        for (int i = 0; i < n; i++) {
            String name = sc.nextLine();
            float[] s = new float[10];
            for (int j = 0; j < 10; j++) {
                s[j] = sc.nextFloat();
            }
            sc.nextLine();
            a.add(new HocSinh(i + 1, name, s));
        }
        Collections.sort(a, new Comparator<HocSinh>() {
            @Override
            public int compare(HocSinh o1, HocSinh o2) {
                if (o1.getDiemTB() < o2.getDiemTB()) {
                    return 1;
                }
                return -1;
            }
        });
        for (int i = 0; i < n; i++) {
            System.out.println(a.get(i));
        }
    }
}
