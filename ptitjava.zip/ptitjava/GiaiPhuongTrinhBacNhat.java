/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.Scanner;
import java.text.DecimalFormat;
public class GiaiPhuongTrinhBacNhat {
    public static void main(String args[]){
        float a, b;
        Scanner sc = new Scanner(System.in);
        a = sc.nextFloat();
        b = sc.nextFloat();
        if(a == 0 && b > 0){
            System.out.println("VN");
        }
        else if(a == 0 && b == 0){
            System.out.println("VSN");
        }
        else{
            float x = (-b) / a;
            DecimalFormat f = new DecimalFormat("0.00");
            System.out.println(f.format(x));
        }
    }
}
