/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import static java.lang.Math.max;
import java.util.*;
public class XauKhacNhauDaiNhat {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        sc.nextLine();
        while(t > 0){
            t--;
            String s1 = sc.next();
            String s2 = sc.next();
            if ( s1.equals(s2)){
                System.out.println(-1);
            }else {
                
                    System.out.println(max(s1.length(),s2.length()));
                
            }
        }
    }
}
