package main.java.com.mycompany.ptitjava;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;

class LopHoc implements Comparable<LopHoc> {
    private String maNhom;
    private String maMon;
    private String tenMon;
    private String ngayDay;
    private String kipHoc;
    private String tenGV;
    private String phongHoc;

    public LopHoc(String maNhom, String maMon, String tenMon, String ngayDay, String kipHoc, String tenGV,
            String phongHoc) {
        this.maNhom = maNhom;
        this.maMon = maMon;
        this.ngayDay = ngayDay;
        this.tenMon = tenMon;
        this.kipHoc = kipHoc;
        this.tenGV = tenGV;
        this.phongHoc = phongHoc;
    }

    public String getTenGV() {
        return tenGV;
    }

    public String getTenMon() {
        return tenMon;
    }

    public String getMaMon() {
        return maMon;
    }

    public String toString() {
        return maNhom + " " + tenMon + " " + ngayDay + " " + kipHoc + " " + phongHoc;
    }

    public int compareTo(LopHoc o) {
        if (this.ngayDay.equals(o.ngayDay)) {
            if (this.kipHoc.equals(o.kipHoc)) {
                return this.tenGV.compareTo(o.tenGV);
            }
            return this.kipHoc.compareTo(o.kipHoc);
        }
        return this.ngayDay.compareTo(o.ngayDay);
    }
}

class MonHoc {
    private String ma;
    private String ten;
    private Integer soTin;

    public MonHoc(String ma, String ten, Integer soTin) {
        this.ma = ma;
        this.ten = ten;
        this.soTin = soTin;
    }

    public String getTen() {
        return ten;
    }
}

public class LichGiangDayTheoMonHoc {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("MONHOC.in"));
        int n = Integer.parseInt(sc.nextLine());
        HashMap<String, MonHoc> hsM = new HashMap<>();
        for (int i = 0; i < n; i++) {
            String id = sc.nextLine();
            hsM.put(id, new MonHoc(id, sc.nextLine(), Integer.parseInt(sc.nextLine())));
        }
        sc = new Scanner(new File("LICHGD.in"));
        n = Integer.parseInt(sc.nextLine());
        ArrayList<LopHoc> arrL = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            String id = String.format("HP%03d", i + 1);
            String idMon = sc.nextLine();
            MonHoc mh = hsM.get(idMon);
            String tenMon = mh.getTen();
            LopHoc lh = new LopHoc(id, idMon, tenMon, sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine());
            arrL.add(lh);
        }
        String[] ten = sc.nextLine().split(" ");
        ArrayList<LopHoc> arrLH = new ArrayList<>();
        for (String t : ten) {
            for (LopHoc lh : arrL) {
                if (lh.getTenGV().equals(t)) {
                    arrLH.add(lh);
                }
            }
        }
        Collections.sort(arrLH);
        ArrayList<String> tenGV = new ArrayList<>();
        for (LopHoc lh : arrLH) {
            String t = lh.getTenGV();
            if (!tenGV.contains(t)) {
                tenGV.add(t);
            }
        }
        for (String t : tenGV) {
            System.out.println("LICH GIANG DAY GIANG VIEN " + arrLH.get(0).getTenGV() + ":");
            for (LopHoc lh : arrLH) {
                System.out.println(lh);
            }
        }
        sc.close();
    }
}