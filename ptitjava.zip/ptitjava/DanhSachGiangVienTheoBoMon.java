package main.java.com.mycompany.ptitjava;

import java.util.*;

class GiangVien {
    private String ID, Name, Khoa;

    public GiangVien(int ID, String Name, String Khoa) {
        this.ID = "GV" + String.format("%02d", ID);
        this.Name = Name;
        this.Khoa = "";
        String[] a = Khoa.toUpperCase().split(" ");
        for (String i : a) {
            this.Khoa += String.valueOf(i.charAt(0));
        }
    }

    public String getID() {
        return this.ID;
    }

    public String getName() {
        return this.Name;
    }

    public String getKhoa() {
        return this.Khoa;
    }

    @Override
    public String toString() {
        return this.ID + " " + this.Name + " " + this.Khoa;
    }
}

public class DanhSachGiangVienTheoBoMon {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int t = Integer.parseInt(scanner.nextLine());
        List<GiangVien> gvien = new ArrayList<GiangVien>();
        for (int i = 0; i < t; i++) {
            gvien.add(new GiangVien(i + 1, scanner.nextLine(), scanner.nextLine()));
        }
        int q = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < q; i++) {
            String khoa = scanner.nextLine();
            String[] x = khoa.trim().toUpperCase().split("\\s+");
            String y = "";
            for (int j = 0; j < x.length; j++) {
                y += String.valueOf(x[j].charAt(0));
            }
            System.out.println("DANH SACH GIANG VIEN BO MON " + y + ":");
            for (int j = 0; j < gvien.size(); j++) {
                if (gvien.get(j).getKhoa().equals(y)) {
                    System.out.println(gvien.get(j));
                }
            }
        }
    }
}
