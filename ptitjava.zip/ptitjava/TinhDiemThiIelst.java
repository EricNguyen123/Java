package main.java.com.mycompany.ptitjava;

import java.util.*;

public class TinhDiemThiIELTS {
    static float trans(int x) {
        if (x >= 3 && x <= 4)
            return (float) 2.5;
        if (x >= 5 && x <= 6)
            return (float) 3.0;
        if (x >= 7 && x <= 9)
            return (float) 3.5;
        if (x >= 10 && x <= 12)
            return (float) 4.0;
        if (x >= 13 && x <= 15)
            return (float) 4.5;
        if (x >= 16 && x <= 19)
            return (float) 5.0;
        if (x >= 20 && x <= 22)
            return (float) 5.5;
        if (x >= 23 && x <= 26)
            return (float) 6.0;
        if (x >= 27 && x <= 29)
            return (float) 6.5;
        if (x >= 30 && x <= 32)
            return (float) 7.0;
        if (x >= 33 && x <= 34)
            return (float) 7.5;
        if (x >= 35 && x <= 36)
            return (float) 8.0;
        if (x >= 37 && x <= 38)
            return (float) 8.5;
        if (x >= 39 && x <= 40)
            return (float) 9.0;
        return 0;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        for (int i = 0; i < t; i++) {
            int r = sc.nextInt();
            int l = sc.nextInt();
            float s = sc.nextFloat();
            float w = sc.nextFloat();
            float x = (float) ((trans(r) + trans(l) + s + w) / 4);
            if (x - (int) x >= 0.75) {
                System.out.println((float) ((int) x + 1));
            } else if (x - (int) x >= 0.25) {
                System.out.println((float) ((int) x + 0.5));
            } else {
                System.out.println(x);
            }
        }
    }
}
