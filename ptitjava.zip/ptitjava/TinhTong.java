/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

import java.util.Scanner;

/**
 *
 * @author huynguyen
 */
public class TinhTong {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        while(n > 0)
        {
            n--;
            int a = sc.nextInt();
            long s = (a + 1) * a / 2;
            System.out.println(s);
        }
        
    }
}
