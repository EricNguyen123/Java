/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
class Xuly{
    String code, name;
    int salary, bl, pc;
    Xuly(String code, String name, int salary){
        this.name = name;
        this.code = code;
        if(code.contains("HT")){
            this.bl = ((int)code.charAt(2) - 48) * 10 + (int)code.charAt(3) - 48;
            this.salary = salary * this.bl + 2000000;
            this.pc = 2000000;
//            System.out.print(code + " " + name + " " + bl + " 2000000" + " " + salary);
        }
        else if(code.contains("HP")){
            this.bl = ((int)code.charAt(2) - 48) * 10 + (int)code.charAt(3) - 48;
            this.salary = salary * this.bl + 900000;
            this.pc = 900000;
//            System.out.print(code + " " + name + " " + bl + " 900000" + " " + salary);
        }
        else{
            this.bl = ((int)code.charAt(2) - 48) * 10 + (int)code.charAt(3) - 48;
            this.salary = salary * this.bl + 500000;
            this.pc = 500000;
//            System.out.print(code + " " + name + " " + bl + " 500000" + " " + salary);
        }
    }
}
public class BangThuNhapGiaoVien {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        Xuly[] x = new Xuly[t];
        for(int i = 0; i < t; i++){
            String v = sc.nextLine();
            String code = sc.nextLine();
            String name = sc.nextLine();
            int salary = sc.nextInt();
            x[i] = new Xuly(code, name, salary);
        }
        int dht = 0;
        int dhp = 0;
        for(int i = 0; i < t; i++){
            if(x[i].code.contains("HT") && dht < 1){
                dht++;
                System.out.println(x[i].code + " " + x[i].name + " " + x[i].bl + " 2000000" + " " + x[i].salary);
            }
            else if(x[i].code.contains("HP") && dhp < 2){
                dhp++;
                System.out.println(x[i].code + " " + x[i].name + " " + x[i].bl + " 900000" + " " + x[i].salary);
            }
            else if(x[i].code.contains("GV")){
                System.out.println(x[i].code + " " + x[i].name + " " + x[i].bl + " 500000" + " " + x[i].salary);
            }
        }
    }
}
