/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.Scanner;
public class PhanTichThuaSoNguyenTo {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int x = 1;
        while(x <= n){
            long a = sc.nextLong();
            int[][] res = new int[100][2];
            int check = 0;
            while(a % 2 == 0){
                check++;
                a /= 2;
            }
            if(check > 0){
                res[0][0] = 2;
                res[0][1] = check;
            }
            int count = 3;
            int d = 1;
            while(a > 1){
                check = 0;
                while(a % count == 0){
                    check++;
                    a /= count;
                }
                if(check > 0){
                    res[d][0] = count;
                    res[d][1] = check;
                    d++;
                }
                count += 2;
            }
            System.out.print("Test " + x + ":");
            if(res[0][1] != 0){
                System.out.print(" " + 2 + "(" + res[0][1] + ")");
            }
            for(int i = 1; i < 100; i ++)
            {
                if(res[i][1] != 0){
                    System.out.print(" " + res[i][0] + "(" + res[i][1] + ")");
                }
            }
            x++;
            System.out.println();
        }
    }
}
