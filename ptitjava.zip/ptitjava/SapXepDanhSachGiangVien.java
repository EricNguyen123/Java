package main.java.com.mycompany.ptitjava;

import java.util.*;

class GiangVien {
    private String ID, Name, Khoa;

    public GiangVien() {
        this.ID = null;
        this.Name = null;
        this.Khoa = null;
    }

    public void input(Scanner scanner, int ID) {
        this.ID = "GV" + String.format("%02d", ID);
        this.Name = scanner.nextLine();
        String Khoa = scanner.nextLine();
        this.Khoa = "";
        String[] a = Khoa.toUpperCase().split(" ");
        for (String i : a) {
            this.Khoa += String.valueOf(i.charAt(0));
        }
    }

    public String getID() {
        return this.ID;
    }

    public String getName() {
        return this.Name;
    }

    public String getKhoa() {
        return this.Khoa;
    }

    @Override
    public String toString() {
        return this.ID + " " + this.Name + " " + this.Khoa;
    }
}

public class SapXepDanhSachGiangVien {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = Integer.parseInt(sc.nextLine());
        List<GiangVien> gvien = new ArrayList<>();
        for (int i = 0; i < t; i++) {
            GiangVien gv = new GiangVien();
            gv.input(sc, i + 1);
            gvien.add(gv);
        }
        Collections.sort(gvien, new Comparator<GiangVien>() {
            @Override
            public int compare(GiangVien o1, GiangVien o2) {
                String[] a = o1.getName().split(" ");
                String[] b = o2.getName().split(" ");
                if (a[a.length - 1].compareTo(b[b.length - 1]) > 0) {
                    return 1;
                } else if (a[a.length - 1].compareTo(b[b.length - 1]) == 0) {
                    if (o1.getID().compareTo(o2.getID()) > 0) {
                        return 1;
                    }
                }
                return -1;
            }
        });
        for (GiangVien i : gvien) {
            System.out.println(i);
        }
    }
}
