package main.java.com.mycompany.ptitjava;

import java.util.*;

class Node {
    private int value;

    public int getValue() {
        return value;
    }

    Node(int x) {
        this.value = x;
    }
}

class myStack {
    private Node[] values;

    myStack() {
        this.values = null;
    }

    public Node[] getValues() {
        return values;
    }

    public void push(Node value) {
        if (values == null) {
            values = new Node[1];
            values[0] = value;
        } else {
            Node[] tmp = new Node[values.length + 1];
            for (int i = 0; i < values.length; i++) {
                tmp[i] = values[i];
            }
            tmp[values.length] = value;
            values = tmp;
        }
    }

    public void pop() {
        Node[] tmp = new Node[values.length - 1];
        for (int i = 0; i < values.length - 1; i++) {
            tmp[i] = values[i];
        }
        values = tmp;
    }
}

public class Stack {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            myStack x = new myStack();
            int t = 5;
            while (t-- > 0) {
                int a = sc.nextInt();
                Node b = new Node(a);
                x.push(b);
            }
            x.pop();
            for (int i = 0; i < x.getValues().length; i++) {
                System.out.println(x.getValues()[i].getValue());
            }
        }
    }
}
