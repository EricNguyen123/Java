/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
public class BaiToanTinhCong {
    public static void main(String[] args){
        Scanner sc= new Scanner(System.in);
        String name = sc.nextLine();
        long salary = sc.nextLong();
        int ngaycong = sc.nextInt();
        String x = sc.nextLine();
        String cv = sc.nextLine();
        if(cv.contentEquals("GD")){
            salary = salary * ngaycong;
            long lt = salary;
            long th;
            long pc = 250000;
            if(ngaycong >= 25){
                th = salary * 20 / 100;
            }
            else if(ngaycong >= 22 && ngaycong < 25){
                th = salary * 10 / 100;
            }
            else{
                th = 0;
            }
            salary = lt + th + pc;
            System.out.print("NV01" + " " + name + " " + lt + " " + th + " " + pc + " " + salary);
        }
        else if(cv.contentEquals("PGD")){
            salary = salary * ngaycong;
            long lt = salary;
            long th;
            long pc = 200000;
            if(ngaycong >= 25){
                th = salary * 20 / 100;
            }
            else if(ngaycong >= 22 && ngaycong < 25){
                th = salary * 10 / 100;
            }
            else{
                th = 0;
            }
            salary = lt + th + pc;
            System.out.print("NV01" + " " + name + " " + lt + " " + th + " " + pc + " " + salary);
        }
        else if(cv.contentEquals("TP")){
            salary = salary * ngaycong;
            long lt = salary;
            long th;
            long pc = 180000;
            if(ngaycong >= 25){
                th = salary * 20 / 100;
            }
            else if(ngaycong >= 22 && ngaycong < 25){
                th = salary * 10 / 100;
            }
            else{
                th = 0;
            }
            salary = lt + th + pc;
            System.out.print("NV01" + " " + name + " " + lt + " " + th + " " + pc + " " + salary);
        }
        else if(cv.contentEquals("NV")){
            salary = salary * ngaycong;
            long lt = salary;
            long th;
            long pc = 150000;
            if(ngaycong >= 25){
                th = salary * 20 / 100;
            }
            else if(ngaycong >= 22 && ngaycong < 25){
                th = salary * 10 / 100;
            }
            else{
                th = 0;
            }
            salary = lt + th + pc;
            System.out.print("NV01" + " " + name + " " + lt + " " + th + " " + pc + " " + salary);
        }
    }
}
