package main.java.com.mycompany.ptitjava;

import java.util.*;

class SinhVien {
    private String STT, ID, Name, Lop, Email, DoanhNghiep;

    public String getSTT() {
        return STT;
    }

    public String getID() {
        return ID;
    }

    public String getName() {
        return Name;
    }

    public String getLop() {
        return Lop;
    }

    public String getEmail() {
        return Email;
    }

    public String getDoanhNghiep() {
        return DoanhNghiep;
    }

    public SinhVien(String STT, String ID, String Name, String Lop, String Email, String DoanhNghiep) {
        this.STT = STT;
        this.ID = ID;
        this.Name = Name;
        this.Lop = Lop;
        this.Email = Email;
        this.DoanhNghiep = DoanhNghiep;
    }

    @Override
    public String toString() {
        return STT + " " + ID + " " + Name + " " + Lop + " " + Email + " " + DoanhNghiep;
    }
}

public class DanhSachThucTap {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<SinhVien> sinhVien = new ArrayList<>();
        int t = Integer.parseInt(sc.nextLine());
        for (int i = 0; i < t; i++) {
            sinhVien.add(
                    new SinhVien(String.valueOf(i + 1), sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine(),
                            sc.nextLine()));
        }
        Collections.sort(sinhVien, new Comparator<SinhVien>() {
            @Override
            public int compare(SinhVien o1, SinhVien o2) {
                // return o1.getName().compareTo(o2.getName());
                return o1.getID().compareTo(o2.getID());
            }
        });
        int q = Integer.parseInt(sc.nextLine());
        for (int i = 0; i < q; i++) {
            String s = sc.nextLine();
            for (int j = 0; j < t; j++) {
                if (s.equals(sinhVien.get(j).getDoanhNghiep())) {
                    System.out.println(sinhVien.get(j));
                }
            }
        }
    }
}
