/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
public class GiaoCuaHaiDaySo {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n, m;
        n = sc.nextInt();
        m = sc.nextInt();
        int[] a = new int[n], b = new int[m];
        Set setA = new HashSet();
        for(int i = 0; i < n; i++){
            a[i] = sc.nextInt();
            setA.add(a[i]);
        }
        Set setB = new HashSet();
        for(int i = 0; i < m; i++){
            b[i] = sc.nextInt();
            if(setA.contains(b[i]) == true){
                setB.add(b[i]);
            }
        }
        Iterator it = setB.iterator();
        while(it.hasNext()){
            System.out.print(it.next() + " ");
        }
        
    }
}
