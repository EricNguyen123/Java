package main.java.com.mycompany.ptitjava;

import java.util.*;

public class TimKiemNhiPhan {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }
        Arrays.sort(arr, 0, n);
        int x = sc.nextInt();
        int l = 0;
        int r = n - 1;
        int d = 0;
        while (l <= r) {
            int mid = l + (r - l) / 2;
            if (arr[mid] == x) {
                d = 1;
                System.out.println("Yes");
                break;
            } else if (arr[mid] < x) {
                l = mid + 1;
            } else {
                r = mid - 1;
            }

        }
        if (d == 0) {
            System.out.println("No");
        }
    }
}
