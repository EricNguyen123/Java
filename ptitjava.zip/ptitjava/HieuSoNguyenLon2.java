/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
public class HieuSoNguyenLon2 {
    static void Hieu(String x, String y){
        int d = 0;
        if(x.length() < y.length()){
            String tmp = x;
            x = y;
            y = tmp;
            d = 1;
        }
        else if(x.length() == y.length() && x.compareTo(y) < 0){
            String tmp = x;
            x = y;
            y = tmp;
            d = 1;
        }
        String res = "";
        int nho = 0;
        int n = x.length();
        int m = y.length();
        while(n > m){
            y = "0" + y;
            m++;
        }
        for(int i = n - 1; i >= 0; i--){
            int s = (int)x.charAt(i) - (int)y.charAt(i) - nho;
            if(s < 0){
                res = String.valueOf(s + 10) + res;
                nho = 1;
            }
            else{
                res = String.valueOf(s) + res;
                nho = 0;
            }
        }
        
        while(res.charAt(0) == '0'){
            if(res.length() == 1){
                break;
            }
            res = res.substring(1);
        }
        if(d == 1 && res.compareTo("0") != 0){
            res = "-" + res;
        }
        System.out.println(res);
    }
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int t = 1;
        
        while(t > 0){
            t--;
            String x = sc.next();
            String y = sc.next();
            while(x.charAt(0) == '0'){
                if(x.length() == 1){
                    break;
                }
                x = x.substring(1);
            }
            while(y.charAt(0) == '0'){
                if(y.length() == 1){
                    break;
                }
                y = y.substring(1);
            }
            
            
            Hieu(x, y);
        }
    }
}
