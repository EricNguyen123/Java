package main.java.com.mycompany.ptitjava;

public interface Bike {
    public void start();
}

class Honda implements Bike {
    public void start() {
        System.out.println("Honda");
    }
}

class Apache implements Bike {
    public void start() {
        System.out.println("Apache");
    }
}

public class Rider {
    public static void main(String[] args) {
        Bike bike = new Honda();
        bike.start();
        Bike train = new Apache();
        train.start();
    }
}
