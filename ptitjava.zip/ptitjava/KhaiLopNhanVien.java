/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
class Staff
{
    private String ID, Name, Sex, dateOfBirth, Address, taxID, contractDate;

    public Staff(String name, String sex, String dateOfBirth, String address, String taxID, String contractDate)
    {
        this.ID = "00001";
        Name = name;
        Sex = sex;
        this.dateOfBirth = dateOfBirth;
        Address = address;
        this.taxID = taxID;
        this.contractDate = contractDate;
    }

    public String getID()
    {
        return ID;
    }

    public void setID(String ID)
    {
        this.ID = ID;
    }

    public String getName()
    {
        return Name;
    }

    public void setName(String name)
    {
        Name = name;
    }

    public String getSex()
    {
        return Sex;
    }

    public void setSex(String sex)
    {
        Sex = sex;
    }

    public String getDateOfBirth()
    {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth)
    {
        this.dateOfBirth = dateOfBirth;
    }

    public String getAddress()
    {
        return Address;
    }

    public void setAddress(String address)
    {
        Address = address;
    }

    public String getTaxID()
    {
        return taxID;
    }

    public void setTaxID(String taxID)
    {
        this.taxID = taxID;
    }

    public String getContractDate()
    {
        return contractDate;
    }

    public void setContractDate(String contractDate)
    {
        this.contractDate = contractDate;
    }
}
public class KhaiLopNhanVien {
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        String[] a = new String[6];
        for (int i = 0; i < 6; ++i)
            a[i] = sc.nextLine();
        Staff A = new Staff(a[0], a[1], a[2], a[3], a[4], a[5]);
        System.out.printf("%s %s %s %s %s %s %s", A.getID(), A.getName(), A.getSex(), A.getDateOfBirth(), A.getAddress(), A.getTaxID(), A.getContractDate());
    }
}
