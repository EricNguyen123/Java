package main.java.com.mycompany.ptitjava;

import java.util.*;

class Bill {
    private String idBill;
    private Customer customer;
    private Product product;
    private int number;

    public Bill(int idBill, Customer customer, Product product, int number) {
        this.idBill = String.format("HD%03d", idBill);
        this.customer = customer;
        this.product = product;
        this.number = number;
    }

    public String toString() {
        return idBill + " " + customer + " " + product + " " + number + " " + number * product.getPrice();
    }
}

class Customer {
    private String idCus;
    private String name;
    private String gender;
    private String dateBirth;
    private String address;

    public Customer() {
    }

    public Customer(int id, String name, String gender, String dateBirth, String address) {
        this.idCus = String.format("KH%03d", id);
        this.name = name;
        this.gender = gender;
        this.dateBirth = dateBirth;
        this.address = address;
    }

    public String getIdCus() {
        return idCus;
    }

    public String toString() {
        return name + " " + address;
    }
}

class Product {
    private String idPr;
    private String name;
    private String unit;
    private long buyMoney;
    private long price;

    public Product() {
    }

    public Product(int idPr, String name, String unit, long buyMoney, long price) {
        this.idPr = String.format("MH%03d", idPr);
        this.name = name;
        this.unit = unit;
        this.buyMoney = buyMoney;
        this.price = price;
    }

    public String getIdPr() {
        return idPr;
    }

    public long getPrice() {
        return price;
    }

    public String toString() {
        return name + " " + unit + " " + buyMoney + " " + price;
    }
}

public class QuanLyBanHang1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = Integer.parseInt(sc.nextLine());
        List<Customer> listCus = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            Customer customer = new Customer(i + 1, sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine());
            listCus.add(customer);
        }
        int m = Integer.parseInt(sc.nextLine());
        List<Product> listPro = new ArrayList<>();
        for (int i = 0; i < m; i++) {
            Product product = new Product(i + 1, sc.nextLine(), sc.nextLine(), Long.parseLong(sc.nextLine()),
                    Long.parseLong(sc.nextLine()));
            listPro.add(product);
        }
        int t = Integer.parseInt(sc.nextLine());
        List<Bill> listBill = new ArrayList<>();
        for (int i = 0; i < t; i++) {
            String[] input = sc.nextLine().trim().split("\\s+");
            String idCus = input[0];
            String idPro = input[1];
            Customer customer = new Customer();
            Product product = new Product();
            for (int j = 0; j < n; j++) {
                if (listCus.get(j).getIdCus().equals(idCus))
                    customer = listCus.get(j);
            }
            for (int j = 0; j < m; j++) {
                if (listPro.get(j).getIdPr().equals(idPro))
                    product = listPro.get(j);
            }
            int number = Integer.parseInt(input[2]);
            Bill bill = new Bill(i + 1, customer, product, number);
            listBill.add(bill);
        }
        for (Bill bill : listBill) {
            System.out.println(bill);
        }
    }
}
