/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.Scanner;
public class TinhLuyThua {
    static int mod = (int)1e9 + 7;
    static long LuyThua(long a, long b){
        if(b == 1){
            return a;
        }
        if(b == 0){
            return 1;
        }
        long p = LuyThua(a,(long)b / 2);
        p = p % mod;
        if(b % 2 == 0){
            return (p * p) % mod;
        }
        else{
            return (p * p) % mod * a % mod;
        }
    }
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        long a, b;
        while(true){
            a = sc.nextLong();
            b = sc.nextLong();
            if(a == 0 && b == 0){
                break;
            }
            System.out.println(LuyThua(a, b));
        }
    }
}