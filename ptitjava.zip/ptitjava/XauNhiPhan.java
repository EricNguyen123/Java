/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.Scanner;
public class XauNhiPhan {
    static long[] len = new long[93];
    static void KhoiTao(long[] len){
        len[0] = 0;
        len[1] = len[2] = 1;
        for(int i = 3; i < 93; i++){
            len[i] = len[i - 2] + len[i - 1];
        }
    }
    static int XuLy(int n, long k, long[] len){
        if(n == 1)
        {
            return 0;
        }
        if(n == 2){
            return 1;
        }
        if(k <= len[n - 2]){
            return XuLy(n - 2, k, len);
        }
        else if(k > len[n - 2] && k <= len[n]){
            return XuLy(n - 1, k - len[n - 2], len);
        }
        return 0;
    }
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        while(t > 0){
            t--;
            int n;
            long k;
            n = sc.nextInt();
            k = sc.nextLong();
            KhoiTao(len);
            System.out.println(XuLy(n, k, len));
        }
    }
}
