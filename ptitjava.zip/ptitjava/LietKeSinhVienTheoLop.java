package main.java.com.mycompany.ptitjava;

import java.util.*;

class SinhVien {
    String ID, Name, Lop, Email;

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        this.Name = name;
    }

    public String getLop() {
        return Lop;
    }

    public void setLop(String lop) {
        this.Lop = lop;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        this.Email = email;
    }

    public SinhVien(String ID, String Name, String Lop, String Email) {
        this.ID = ID;
        this.Name = Name;
        this.Lop = Lop;
        this.Email = Email;
    }
}

public class LietKeSinhVienTheoLop {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = Integer.parseInt(sc.nextLine());
        List<SinhVien> sinhVien = new ArrayList<>();
        while (t-- > 0) {
            sinhVien.add(new SinhVien(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine()));
        }
        int q = Integer.parseInt(sc.nextLine());
        List<String> lop = new ArrayList<String>();
        while (q-- > 0) {
            lop.add(sc.nextLine());
        }
        for (int i = 0; i < lop.size(); i++) {
            System.out.println("DANH SACH SINH VIEN LOP " + lop.get(i) + ":");
            for (int j = 0; j < sinhVien.size(); j++) {
                if (sinhVien.get(j).getLop().equals(lop.get(i))) {
                    System.out.println(sinhVien.get(j).getID() + " "
                            + sinhVien.get(j).getName() + " "
                            + sinhVien.get(j).getLop() + " "
                            + sinhVien.get(j).getEmail());
                }
            }
        }
    }
}
