package main.java.com.mycompany.ptitjava;

import java.util.*;
import HV.java;

public class MainHH {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        long a = scanner.nextLong();
        HV x = new HV(a);
        System.out.println(x);
    }
}
