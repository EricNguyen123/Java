/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
public class LietKeToHop_2 {
    static int[] x = new int[11];
    static int d = 0;
    static void ToHop(int i, int n, int k){
        for(int j = x[i - 1] + 1; j <= n - i + k; j++){
            x[i] = j;
            if(i == k){
                for(int l = 1; l <= k; l++){
                    System.out.print(x[l]);
                }
                System.out.print(" ");
                d++;
            }
            else{
                ToHop(i + 1, n, k);
            }
        }
    }
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int t = 1;
        while(t > 0){
            t--;
            int n, k;
            n = sc.nextInt();
            k = sc.nextInt();
            d = 0;
            ToHop(1, n, k);
            System.out.println();
            System.out.println("Tong cong co " + d + " to hop");
        }
    }
}

