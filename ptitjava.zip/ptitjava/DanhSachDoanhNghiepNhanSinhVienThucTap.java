package main.java.com.mycompany.ptitjava;

import java.util.*;

class DoanhNghiep {
    private String ID, Name, Sluong;

    public DoanhNghiep(String ID, String Name, String Sluong) {
        this.ID = ID;
        this.Name = Name;
        this.Sluong = Sluong;
    }

    public String getID() {
        return ID;
    }

    public String getName() {
        return Name;
    }

    public String getSluong() {
        return Sluong;
    }

    @Override
    public String toString() {
        return this.ID + " " + this.Name + " " + this.Sluong;
    }

}

public class DanhSachDoanhNghiepNhanSinhVienThucTap {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = Integer.parseInt(sc.nextLine());
        List<DoanhNghiep> doanhNghiep = new ArrayList<DoanhNghiep>();
        while (n-- > 0) {
            doanhNghiep.add(new DoanhNghiep(sc.nextLine(), sc.nextLine(), sc.nextLine()));
        }
        Collections.sort(doanhNghiep, new Comparator<DoanhNghiep>() {
            @Override
            public int compare(DoanhNghiep o1, DoanhNghiep o2) {
                if (o1.getSluong() == o2.getSluong())
                    return o1.getID().compareTo(o2.getID());
                return Integer.parseInt(o2.getSluong()) - Integer.parseInt(o1.getSluong());
            }
        });
        for (DoanhNghiep i : doanhNghiep) {
            System.out.println(i);
        }
    }
}
