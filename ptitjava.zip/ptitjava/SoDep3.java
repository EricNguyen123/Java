/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
public class SoDep3 {
    static int ThuanNgich(String s){
        int l = 0;
        int r = s.length() - 1;
        while(l <= r){
            if(s.charAt(l) == s.charAt(r) && (s.charAt(r) == '2' || s.charAt(r) == '3' || s.charAt(r) == '5' || s.charAt(r) == '7')){
                l++;
                r--;
            }
            else{
                return 0;
            }
        }
        return 1;
    }
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        while(n > 0){
            n--;
            String s = sc.next();
            if(ThuanNgich(s) == 1){
                
                    System.out.println("YES");
               
            }
            else{
                System.out.println("NO");
            }
        }
    }
}
