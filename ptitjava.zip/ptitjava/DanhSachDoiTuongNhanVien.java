package main.java.com.mycompany.ptitjava;

import java.util.*;

class ChuanHoaNgay {
    private String Date;

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        this.Date = date;
    }

    public ChuanHoaNgay(String date) {
        String[] a = new String[3];
        a = date.split("/");
        while (a[0].length() < 2) {
            a[0] = "0" + a[0];
        }
        while (a[1].length() < 2) {
            a[1] = "0" + a[1];
        }

        this.Date = a[0] + "/" + a[1] + "/" + a[2];
    }
}

class NhanVien {
    private String MaNhanVien, Ten, GioiTinh, NgaySinh, DiaChi, MaSoThue, NgayKyHopDong;

    public String getMaNhanVien() {
        return MaNhanVien;
    }

    public void setMaNhanVien(String MaNhanVien) {
        this.MaNhanVien = MaNhanVien;
    }

    public String getTen() {
        return Ten;
    }

    public void setTen(String Ten) {
        this.Ten = Ten;
    }

    public String getGioiTinh() {
        return GioiTinh;
    }

    public void setGioiTinh(String GioiTinh) {
        this.GioiTinh = GioiTinh;
    }

    public String getNgaySinh() {
        return NgaySinh;
    }

    public void setNgaySinh(String NgaySinh) {
        this.NgaySinh = NgaySinh;
    }

    public String getDiaChi() {
        return DiaChi;
    }

    public void setDiaChi(String DiaChi) {
        this.DiaChi = DiaChi;
    }

    public String getMaSoThue() {
        return MaSoThue;
    }

    public void setMaSoThue(String MaSoThue) {
        this.MaSoThue = MaSoThue;
    }

    public String getNgayKyHopDong() {
        return NgayKyHopDong;
    }

    public void setNgayKyHopDong(String NgayKyHopDong) {
        this.NgayKyHopDong = NgayKyHopDong;
    }

    public NhanVien(int MaNhanVien, String Ten, String GioiTinh, String NgaySinh, String DiaChi, String MaSoThue,
            String NgaykyHopDong) {
        String code = String.valueOf(MaNhanVien);
        while (code.length() < 5) {
            code = "0" + code;
        }
        this.MaNhanVien = code;
        String s = Ten;
        s = s.trim().toLowerCase();
        s = s.replaceAll("\\s+", " ");
        String res = "";
        String[] tmp = s.split(" ");
        for (String tmp1 : tmp) {
            res += String.valueOf(tmp1.charAt(0)).toUpperCase() + tmp1.substring(1) + " ";
        }
        res = res.trim();
        this.Ten = res;
        this.GioiTinh = GioiTinh;
        ChuanHoaNgay date = new ChuanHoaNgay(NgaySinh);
        this.NgaySinh = date.getDate();
        this.DiaChi = DiaChi;
        this.MaSoThue = MaSoThue;
        date = new ChuanHoaNgay(NgaykyHopDong);
        this.NgayKyHopDong = date.getDate();
    }

}

public class DanhSachDoiTuongNhanVien {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            List<NhanVien> nv = new ArrayList<>();
            int t = sc.nextInt();
            int i = 0;
            sc.nextLine();
            while (t > 0) {

                t--;
                i++;
                int MaNhanVien = i;
                String Ten = sc.nextLine();
                String GioiTinh = sc.nextLine();
                String NgaySinh = sc.nextLine();
                String DiaChi = sc.nextLine();
                String MaSoThue = sc.nextLine();
                String NgayKyHopDong = sc.nextLine();
                nv.add(new NhanVien(MaNhanVien, Ten, GioiTinh, NgaySinh, DiaChi, MaSoThue, NgayKyHopDong));

            }

            Collections.sort(nv, new Comparator<NhanVien>() {
                @Override
                public int compare(NhanVien o1, NhanVien o2) {
                    String[] a = o1.getNgaySinh().split("/");
                    String[] b = o2.getNgaySinh().split("/");
                    if (a[2].compareTo(b[2]) < 0) {
                        return -1;
                    } else if (a[2].compareTo(b[2]) == 0) {
                        if (a[1].compareTo(b[1]) < 0) {
                            return -1;
                        } else if (a[1].compareTo(b[1]) == 0) {
                            if (a[0].compareTo(b[0]) < 0) {
                                return -1;
                            } else if (a[0].compareTo(b[0]) == 0) {
                                return 0;
                            } else {
                                return 1;
                            }

                        } else {
                            return 1;
                        }
                    } else {
                        return 1;
                    }

                }
            });

            for (NhanVien vien : nv) {
                System.out.println(vien.getMaNhanVien() + " "
                        + vien.getTen() + " "
                        + vien.getGioiTinh() + " "
                        + vien.getNgaySinh() + " "
                        + vien.getDiaChi() + " "
                        + vien.getMaSoThue() + " "
                        + vien.getNgayKyHopDong());
            }
        }
    }
}
