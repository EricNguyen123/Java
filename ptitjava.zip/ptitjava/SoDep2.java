/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
public class SoDep2 {
    static int ThuanNgich(String s){
        int l = 0;
        int r = s.length() - 1;
        if(s.charAt(l) == s.charAt(r) && s.charAt(r) != '8'){
            return 0;
        }
        while(l <= r){
            if(s.charAt(l) == s.charAt(r)){
                l++;
                r--;
            }
            else{
                return 0;
            }
        }
        return 1;
    }
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        while(n > 0){
            n--;
            String s = sc.next();
            if(ThuanNgich(s) == 1){
                int sum = 0;
                for(int i = 0; i < s.length(); i++){
                    sum += (int)s.charAt(i) - 48;
                }
                if(sum % 10 == 0){
                    System.out.println("YES");
                } 
                else{
                    System.out.println("NO");
                }
            }
            else{
                System.out.println("NO");
            }
        }
    }
}
