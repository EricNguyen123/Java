/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
public class ThuDonDaySo {
    public static void main(String[] agrs) { 
        Scanner sc = new Scanner(System.in); 
        int n = sc.nextInt(); 
        ArrayList<Integer> a = new ArrayList<Integer>(); 
        for (int i = 0; i < n; i++) { 
            a.add(sc.nextInt()); 
            
        } 
        boolean b = true; 
        while (b) { 
            b = false; 
            for (int i = 0; i < a.size() - 1; i++) { 
                if ((a.get(i) + a.get(i + 1)) % 2 == 0) { 
                    a.remove(i); 
                    a.remove(i); 
                    b=true; 
                    
                } 
                
            } 
            
        } 
        System.out.print(a.size()); 
        
    } 
}
