/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
public class ĐanhauChuCai {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String s = sc.next();
        String[] res = new String[28];
        res[0] = String.valueOf(s.charAt(0));
        int d = 1;
        for(int i = 1; i < s.length(); i++){
            int k = 0;
            for(int j = 0; j < d; j++){
                if(res[j].equals(String.valueOf(s.charAt(i)))){
                    k = 1;
                    break;
                }
               
            }
            if(k == 0){
                res[d] = String.valueOf(s.charAt(i));
                d++;
            }
        }
        System.out.println(d);
    }
}
