package main.java.com.mycompany.ptitjava;

import java.util.*;

class So {
    private int a, b;

    public So(int a, int b) {
        this.a = a;
        this.b = b;
    }

    public int getA() {
        return a;
    }

    public int getB() {
        return b;
    }

    public void setA(int a) {
        this.a = a;
    }

    public void setB(int b) {
        this.b = b;
    }

    public So Tong(So x) {
        So res = new So(this.a + x.getA(), this.b + x.getB());
        return res;
    }

    public So Tich(So x) {
        So res = new So(this.a * x.getA() - this.b * x.getB(), this.a * x.getB() + this.b * x.getA());
        return res;
    }

    @Override
    public String toString() {
        String res = "";
        res += String.valueOf(this.a);
        if (this.b < 0) {
            res += " - ";
            res += String.valueOf(-this.b) + "i";
        } else {
            res += " + ";
            res += String.valueOf(this.b) + "i";
        }
        return res;
    }
}

public class SoPhuc {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int t = scanner.nextInt();
        while (t-- > 0) {
            So a = new So(scanner.nextInt(), scanner.nextInt());
            So b = new So(scanner.nextInt(), scanner.nextInt());
            So x = a.Tong(b);
            System.out.println(x.Tich(a) + ", " + x.Tich(x));
        }
    }
}
