package main.java.com.mycompany.ptitjava;

import java.util.*;
import java.lang.*;

class MonHoc {
    private String MaMH, NameMH;

    public MonHoc(String MaMH, String NameMH) {
        this.MaMH = MaMH;
        this.NameMH = NameMH;
    }

    public String getMaMH() {
        return this.MaMH;
    }

    public String getNameMH() {
        return this.NameMH;
    }

    public void setMaMH(String MaMH) {
        this.MaMH = MaMH;
    }

    public void setNameMH(String NameMH) {
        this.NameMH = NameMH;
    }
}

class GiangVien {
    private String MaGV, NameGV;

    public GiangVien(String MaGV, String NameGV) {
        this.MaGV = MaGV;
        this.NameGV = NameGV;
    }

    public String getMaGV() {
        return this.MaGV;
    }

    public String getNameGV() {
        return this.NameGV;
    }

    public void setMaGV(String MaGV) {
        this.MaGV = MaGV;
    }

    public void setNameGV(String NameGV) {
        this.NameGV = NameGV;
    }
}

class GioDay {
    private GiangVien GV;
    private MonHoc MH;
    private double Gio;

    public GioDay(GiangVien GV, MonHoc MH, double Gio) {
        this.GV = GV;
        this.MH = MH;
        this.Gio = Gio;
    }

    public GiangVien getGV() {
        return this.GV;
    }

    public MonHoc getMH() {
        return this.MH;
    }

    public double getGio() {
        return this.Gio;
    }

    public void setGV(GiangVien GV) {
        this.GV = GV;
    }

    public void setMH(MonHoc MH) {
        this.MH = MH;
    }

    public void setGio(double Gio) {
        this.Gio = Gio;
    }

    @Override
    public String toString() {
        return this.MH.getNameMH() + " " + this.Gio;

    }
}

public class TinhGioChuanChoTungGiangVien {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = Integer.parseInt(sc.nextLine());
        List<MonHoc> mh = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            String[] a = sc.nextLine().trim().split("\\s+");
            String ID = a[0];
            String Name = "";
            for (int j = 1; j < a.length; j++) {
                Name += a[j];
            }
            mh.add(new MonHoc(ID, Name));
        }
        int m = Integer.parseInt(sc.nextLine());
        List<GiangVien> gv = new ArrayList<>();
        for (int i = 0; i < m; i++) {
            String[] a = sc.nextLine().trim().split("\\s+");
            String ID = a[0];
            String Name = "";
            for (int j = 1; j < a.length; j++) {
                Name += a[j];
            }
            gv.add(new GiangVien(ID, Name));
        }
        int k = Integer.parseInt(sc.nextLine());
        List<GioDay> gio = new ArrayList<>();
        for (int i = 0; i < k; i++) {
            String[] a = sc.nextLine().trim().split("\\s+");
            String IDGV = a[0];
            String IDMH = a[1];
            double gioday = Double.parseDouble(a[2]);
            GiangVien gV = gv.stream().filter(s -> s.getMaGV().equals(IDGV)).findFirst().get();
            MonHoc mH = mh.stream().filter(s -> s.getMaMH().equals(IDMH)).findFirst().get();
            gio.add(new GioDay(gV, mH, gioday));
        }
        String MaGiangVien = sc.nextLine();
        List<GioDay> gioday = new ArrayList<>();
        for (int i = 0; i < gio.size(); i++) {
            if (gio.get(i).getGV().getMaGV().equals(MaGiangVien)) {
                gioday.add(gio.get(i));
            }
        }
        double time = 0;
        System.out.println("Giang vien: " + gioday.get(0).getGV().getNameGV());
        for (int i = 0; i < gioday.size(); i++) {
            System.out.println(gioday.get(i));
            time += gioday.get(i).getGio();
        }
        System.out.println("Tong: " + String.format("%.2f", time));
        sc.close();
    }

}