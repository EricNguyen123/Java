/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
public class SoUuThe {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        sc.nextLine();
        while(t > 0){
            t--;
            String s = sc.next();
            if(s.length() % 2 == 0){
                int dc = 0, dl = 0;
                int d = 0;
                for(int i = 0; i < s.length(); i++){
                    if(!Character.isDigit(s.charAt(i)) || s.charAt(0) == '0'){
                        d = 1;
                        break;
                    }
                    if((int)s.charAt(i) % 2 == 0){
                        dc++;
                    }
                    else{
                        dl++;
                    }
                }
                if(d == 0){
                    if(dc > dl){
                        System.out.println("YES");
                    }
                    else{
                        System.out.println("NO");
                    }
                }
                else{
                    System.out.println("INVALID");
                }
            }
            else{
                int dc = 0, dl = 0;
                int d = 0;
                for(int i = 0; i < s.length(); i++){
                    if(!Character.isDigit(s.charAt(i)) || s.charAt(0) == '0'){
                        d = 1;
                        break;
                    }
                    if((int)s.charAt(i) % 2 == 0){
                        dc++;
                    }
                    else{
                        dl++;
                    }
                }
                if(d == 0){
                    if(dc < dl){
                        System.out.println("YES");
                    }
                    else{
                        System.out.println("NO");
                    }
                }
                else{
                    System.out.println("INVALID");
                }
            }
        }
    }
}
