/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
public class BienSoDep {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
	while (t-- > 0)
	{
		String a = sc.next();
		int s = 4;
		s++;
		a = a.substring(s);
		
		if(a.charAt(0) == a.charAt(1) && a.charAt(1) == a.charAt(2) && a.charAt(2) == a.charAt(4) && a.charAt(4) == a.charAt(5))
		{
			System.out.println("YES");
		}
		else if (a.charAt(0) == a.charAt(1) && a.charAt(1) == a.charAt(2) && a.charAt(4) == a.charAt(5))
		{
			System.out.println("YES");
		}
		else if (a.charAt(0) + 1 == a.charAt(1) && a.charAt(1) + 1 == a.charAt(2) && a.charAt(2) + 1 == a.charAt(4) && a.charAt(4) + 1 == a.charAt(5))
		{
			System.out.println("YES");
		}
		else if ((a.charAt(0) == '6' || a.charAt(0) == '8') && (a.charAt(1) == '6' || a.charAt(1) == '8') && (a.charAt(2) == '6' || a.charAt(2) == '8' )&& (a.charAt(4) == '6' || a.charAt(4) == '8' )&&(  a.charAt(5) == '6' ||  a.charAt(5)== '8'))
		{
			System.out.println("YES");
                }
		else
		{
			System.out.println("NO");
		}
	}
    }
}
