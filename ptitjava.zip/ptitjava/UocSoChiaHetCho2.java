/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.Scanner;
public class UocSoChiaHetCho2 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        while(n > 0){
            n--;
            long a = sc.nextLong();
            int d = 0;
            for(long i = 1; i <= (long)Math.sqrt(a); i++){
                if(a % i == 0){
                    if(i % 2 == 0){
                        d++;
                    }
                    if(a / i % 2 == 0 && a / i != i){
                        d++;
                    }
                }
            }
            
            System.out.println(d);
        }
    }
}
