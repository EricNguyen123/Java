package main.java.com.mycompany.ptitjava;

import java.util.*;

class Player {
    private String code, playerName, timeSt, timeEn, time;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public String getTimeSt() {
        return timeSt;
    }

    public void setTimeSt(String timeSt) {
        this.timeSt = timeSt;
    }

    public String getTimeEn() {
        return timeEn;
    }

    public void setTimeEn(String timeEn) {
        this.timeEn = timeEn;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Player(String code, String playerName, String timeSt, String timeEn) {
        this.code = code;
        this.playerName = playerName;
        this.timeSt = timeSt;
        this.timeEn = timeEn;
        String[] a = timeSt.split(":");
        String[] b = timeEn.split(":");
        int x = Integer.valueOf(b[0]) - Integer.valueOf(a[0]);
        int y = Integer.valueOf(b[1]) - Integer.valueOf(a[1]);
        int z = x * 60 + y;
        x = z / 60;
        y = z % 60;
        String s = String.valueOf(x);
        String e = String.valueOf(y);
        while (s.length() < 2) {
            s = "0" + s;
        }
        while (e.length() < 2) {
            e = "0" + e;
        }
        this.time = s + ":" + e;
    }
}

public class TinhGio {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Player> players = new ArrayList<Player>();
        int t = sc.nextInt();
        sc.nextLine();
        while (t > 0) {
            t--;
            String code, playerName, timeSt, timeEn;
            code = sc.next();
            sc.nextLine();
            playerName = sc.nextLine();
            timeSt = sc.nextLine();
            timeEn = sc.nextLine();
            players.add(new Player(code, playerName, timeSt, timeEn));
        }
        Collections.sort(players, new Comparator<Player>() {
            @Override
            public int compare(Player o1, Player o2) {
                String[] x = o1.getTime().split(":");
                String[] y = o2.getTime().split(":");
                if (x[0].compareTo(y[0]) < 0) {
                    return 1;
                } else if (x[0].compareTo(y[0]) == 0) {
                    if (x[1].compareTo(y[1]) < 0) {
                        return 1;
                    } else if (x[1].compareTo(y[1]) > 0) {
                        return -1;
                    }
                } else {
                    return -1;
                }
                return 0;
            }
        });
        for (Player p : players) {
            String[] x = p.getTime().split(":");
            System.out.println(p.getCode() + " " + p.getPlayerName() + " " + x[0] + " gio " + x[1] + " phut");
        }
    }
}
