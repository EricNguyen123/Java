package main.java.com.mycompany.ptitjava;

import java.util.*;

public class vd {
    public int add(int a, int b) {
        return a + b;
    }

    public float add(float a, float b) {
        return a + b;
    }

    public String add(String a, String b) {
        return a + b;
    }

    public static void main(String[] args) {
        vd myVD = new vd();
        System.out.println(myVD.add(2, 3));
        System.out.println(myVD.add(4.5f, 5.5f));
        System.out.println(myVD.add("as", "asd"));
    }
}
