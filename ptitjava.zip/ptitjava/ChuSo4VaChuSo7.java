/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.Scanner;
public class ChuSo4VaChuSo7 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String n = sc.next();
        int res = 0;
        for(int i = 0; i < n.length(); i++){
            if(n.charAt(i) == '4' || n.charAt(i) == '7'){
                res++;
            }
        }
        if(res == 4 || res == 7){
            System.out.println("YES");
        }
        else{
            System.out.println("NO");
        }
    }
}
