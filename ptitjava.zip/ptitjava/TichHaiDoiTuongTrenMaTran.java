package main.java.com.mycompany.ptitjava;

import java.util.*;

class Matrix {
    private int x, y;
    private int[][] a;

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int[][] getA() {
        return a;
    }

    public void setA(int[][] a) {
        this.a = a;
    }

    public Matrix(int x, int y) {
        this.x = x;
        this.y = y;
        this.a = new int[x][y];
    }

    public void nextMatrix(Scanner sc) {
        a = new int[x][y];
        for (int i = 0; i < x; i++) {
            for (int j = 0; j < y; j++) {
                a[i][j] = sc.nextInt();
            }
        }
    }

    @Override
    public String toString() {
        String res = "";
        for (int i = 0; i < x; i++) {
            for (int j = 0; j < y; j++) {
                res += String.valueOf(a[i][j]) + " ";
            }
            res += "\n";
        }
        return res;
    }

    public Matrix mul(Matrix s) {
        Matrix c = new Matrix(this.x, s.getY());
        for (int i = 0; i < this.x; i++) {
            for (int j = 0; j < s.getY(); j++) {
                c.a[i][j] = 0;
                for (int k = 0; k < this.y; k++) {
                    c.a[i][j] += this.a[i][k] * s.a[k][j];
                }
            }
        }
        return c;
    }
}

public class TichHaiDoiTuongTrenMaTran {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt(), m = sc.nextInt(), p = sc.nextInt();
        Matrix a = new Matrix(n, m);
        a.nextMatrix(sc);
        Matrix b = new Matrix(m, p);
        b.nextMatrix(sc);
        System.out.println(a.mul(b));
    }
}
