/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
import java.lang.*;
import java.text.*;
class Data{
    String name;
    String date;
    float a, b, c;
    float tong;
    int stt;
    Data(int stt ,String name, String date, float a, float b, float c){
        this.name = name;
        this.date = date;
        this.stt = stt;
        this.a = a;
        this.b = b;
        this.c = c;
        this.tong = a + b + c;
    }
}
public class TimThuKhoa {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        float Max = 0;
        Data[] sv = new Data[t];
        for(int i = 1; i <= t; i++){
            String x = sc.nextLine();
            String name = sc.nextLine();
            String date = sc.nextLine();
            float a = sc.nextFloat(), b = sc.nextFloat(), c = sc.nextFloat();
            sv[i - 1] = new Data(i, name, date, a, b, c);
            Max = Math.max(Max, sv[i - 1].tong);
        }
        for(int i = 0; i < t; i++){
            if(Max == sv[i].tong){
                DecimalFormat f = new DecimalFormat("0.0");
                System.out.println(sv[i].stt + " " + sv[i].name + " " + sv[i].date + " " + f.format(sv[i].tong));
            }
        }
    }
}
