/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
import java.lang.*;
class NhanVien{
    String ma, ten, cv;
    int pc, lc, tu, cl, nc, lcb;
    NhanVien(String ten, String cv, int lcb, int nc, int code){
        this.ten = ten;
        this.cv = cv;
        this.lcb = lcb;
        this.nc = nc;
        String x = String.valueOf(code);
        while(x.length() < 2){
            x = "0" + x;
        }
        this.ma = "NV" + x;
        if("GD".equals(this.cv)){
            this.pc = 500;
        }
        else if("PGD".equals(this.cv)){
            this.pc = 400;          
        }
        else if("TP".equals(this.cv)){
            this.pc = 300;
        }
        else if("KT".equals(this.cv)){
            this.pc = 250;
        }
        else{
            this.pc = 100;
        }
        this.lc = this.lcb * this.nc;
        if((this.pc + this.lc) * 2 / 3 < 25000){
            this.tu = (this.pc + this.lc) * 2 / 3;
            this.tu = Math.round((float)this.tu / 1000) * 1000;
        }
        else{
            this.tu = 25000;
        }
        this.cl = this.lc + this.pc - this.tu;
    }
}
public class SapXepNhanVienTheoThuNhap {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        NhanVien[] nv = new NhanVien[t];
        for(int i = 0; i < t; i++){
            String x = sc.nextLine();
            String ten = sc.nextLine(), cv = sc.nextLine();
            int nc = sc.nextInt(), lcb = sc.nextInt();
            nv[i] = new NhanVien(ten, cv, lcb, nc, i + 1);           
        }
        for(int i = 0; i < t - 1; i++){
            for(int j = i + 1; j < t; j++){
                if(nv[i].lc + nv[i].pc < nv[j].lc + nv[j].pc){
                    NhanVien tmp = nv[i];
                    nv[i] = nv[j];
                    nv[j] = tmp;
                }
                else if(nv[i].lc + nv[i].pc == nv[j].lc + nv[j].pc){
                    if(nv[i].ma.compareTo(nv[j].ma) > 0){
                        NhanVien tmp = nv[i];
                        nv[i] = nv[j];
                        nv[j] = tmp;
                    }
                }
            }
        }
        for(int i = 0; i < t; i++){
            System.out.println(nv[i].ma + " " + nv[i].ten + " " + nv[i].pc + " " + nv[i].lc + " " + nv[i].tu + " " + nv[i].cl);
        }
    }
}
