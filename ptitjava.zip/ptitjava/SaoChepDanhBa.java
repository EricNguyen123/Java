package main.java.com.mycompany.ptitjava;
import java.util.*;
class note{
    String a, b, c;
    public note(String a, String b, String c){
        this.a = a;
        this.b = b;
        this.c = c;
    }
}
public class SaoChepDanhBa {
    public static void main(String[] args){
        Scanner scanner = new Scanner(new File("SOTAY.txt"));
        Scanner sc = new Scanner(new File("DIENTHOAI.txt"));
        note[] x = new note[1000];
        int i = 0;
        while (scanner.hasNextLine()){
            x[i] = new note(scanner.nextLine(), scanner.nextLine(), scanner.nextLine());
            i++;
        }
        scanner.close();
    }
}
