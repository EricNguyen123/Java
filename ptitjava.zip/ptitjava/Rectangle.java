
package com.mycompany.ptitjava;

import java.util.*;
class HCN {
    private int a, b;
    HCN(int a, int b){
        this.a = a;
        this.b = b;
    }
    HCN(int x){
        this.a = this.b = x;
    }
    public void in(){
        if(a == b){
            System.out.println("Hinh vuong canh:" + a);
        }
        else{
            System.out.println("Hinh chu nhat canh:" + a + " " + b);
        }
    }
}
public class Rectangle {
    public static void main(String[] args){
        int a, b;
        Scanner sc = new Scanner(System.in);
        a = sc.nextInt();
        b = sc.nextInt();
        HCN s = new HCN(a, b);
        s.in();
        HCN v = new HCN(a);
        v.in();
    }
}

