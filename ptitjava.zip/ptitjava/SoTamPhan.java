/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.Scanner;
public class SoTamPhan {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        while(n > 0){
            n--;
            String s = sc.next();
            int d = 0;
            int m = s.length();
            for(int i = 0; i < m; ++i){
//                System.out.println(s.charAt(i));
                if((int)s.charAt(i) < 48 || (int)s.charAt(i) > 50){
                    d = 1;
                    break;
                }
            }
            if(d == 0){
                System.out.println("YES");
            }
            else{
                System.out.println("NO");
            }
        }
    }
}
