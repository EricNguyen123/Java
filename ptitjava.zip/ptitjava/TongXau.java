package main.java.com.mycompany.ptitjava;
public interface TongXau {
    public void CongXau();
}
