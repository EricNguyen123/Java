package main.java.com.mycompany.ptitjava;

import java.math.BigInteger;
import java.util.Scanner;

public class TongSoNguyenLon {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int t = scan.nextInt();
        while (t-- > 0) {
            BigInteger a = scan.nextBigInteger();
            BigInteger b = scan.nextBigInteger();
            System.out.println(a.add(b));
        }
    }
}