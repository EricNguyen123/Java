/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.Scanner;
public class SoLienKe {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        while(t > 0){
            t--;
            String n = sc.next();
            int m = n.length() - 1;
            int d = 0;
            for(int i = 0; i < m; i++){
                if((int)n.charAt(i) + 1 != (int)n.charAt(i + 1) && (int)n.charAt(i) != (int)n.charAt(i + 1) + 1){
                    System.out.println("NO");
                    d = 1;
                    break;
                }
            }
            if(d == 0){
                System.out.println("YES");
            }
        }
    }
}
