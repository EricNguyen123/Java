/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
 class Fraction
{
    private long numerator, denominator;

    public Fraction(long numerator, long denominator)
    {
        this.numerator = numerator;
        this.denominator = denominator;
    }

    public long getNumerator()
    {
        return numerator;
    }

    public void setNumerator(long numerator)
    {
        this.numerator = numerator;
    }

    public long getDenominator()
    {
        return denominator;
    }

    public void setDenominator(long denominator)
    {
        this.denominator = denominator;
    }

    public long gcd(long a, long b)
    {
        if (b == 0)
            return a;
        return gcd(b, a % b);
    }

    public void reduceFraction()
    {
        long GCD = gcd(this.numerator, this.denominator);
        this.numerator /= GCD;
        this.denominator /= GCD;
    }

    public void add(Fraction A)
    {
        long LCM = this.denominator * A.denominator / gcd(this.denominator, A.denominator);
        this.numerator *= LCM / this.denominator;
        A.numerator *= LCM / A.denominator;
        this.denominator = LCM;
        this.numerator += A.numerator;
        this.reduceFraction();
    }
}
public class TongPhanSo {
     public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        long a = sc.nextLong(), b = sc.nextLong();
        Fraction A = new Fraction(a, b);
        a = sc.nextLong();
        b = sc.nextLong();
        Fraction B = new Fraction(a, b);
        A.add(B);
        System.out.print(A.getNumerator() + "/" + A.getDenominator());
    }
}
