package main.java.com.mycompany.ptitjava;

import java.util.*;

class SanPham {
    private String ma;
    private String ten;
    private Integer giaL1;
    private Integer giaL2;

    public SanPham(String ma, String ten, Integer giaL1, Integer giaL2) {
        this.ma = ma;
        this.ten = ten;
        this.giaL1 = giaL1;
        this.giaL2 = giaL2;
    }

    public String getMa() {
        return ma;
    }

    public String getTen() {
        return ten;
    }

    public Integer getGiaL1() {
        return giaL1;
    }

    public Integer getGiaL2() {
        return giaL2;
    }
}

class HoaDon implements Comparable<HoaDon> {
    private String ma;
    private SanPham sp;
    private Long soLuong;

    public HoaDon(String ma, Long soLuong, SanPham sp) {
        this.ma = ma;
        this.soLuong = soLuong;
        this.sp = sp;
    }

    public Long thanhTien() {
        String loai = this.ma.charAt(2) + "";
        if (loai.equals("1")) {
            return this.soLuong * sp.getGiaL1();
        }
        return this.soLuong * sp.getGiaL2();
    }

    public Long giamGia() {
        long tmp = thanhTien();
        if (soLuong >= 150) {
            return (long) (tmp * 50 / 100.0);
        } else if (soLuong >= 100) {
            return (long) (tmp * 30 / 100.0);
        } else if (soLuong >= 50) {
            return (long) (tmp * 15 / 100.0);
        }
        return tmp * 0;
    }

    public Long tienPhaiTra() {
        return thanhTien() - giamGia();
    }

    public String toString() {
        return ma + " " + sp.getTen() + " " + giamGia() + " " + tienPhaiTra();
    }

    public int compareTo(HoaDon o) {
        return -1 * this.tienPhaiTra().compareTo(o.tienPhaiTra());
    }

}

public class SapXepHoaDonBanQuanAo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = Integer.parseInt(sc.nextLine());
        ArrayList<SanPham> arrS = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            arrS.add(new SanPham(sc.nextLine(), sc.nextLine(), Integer.parseInt(sc.nextLine()),
                    Integer.parseInt(sc.nextLine())));
        }
        n = Integer.parseInt(sc.nextLine());
        ArrayList<HoaDon> arrH = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            String[] data = sc.nextLine().split("\\s+");
            String ma = String.format("-%03d", i + 1);
            SanPham sp = arrS.stream().filter(s -> s.getMa().equals(data[0].substring(0, 2))).findFirst().get();
            arrH.add(new HoaDon(data[0] + ma, Long.parseLong(data[1]), sp));
        }
        Collections.sort(arrH);
        for (HoaDon hd : arrH) {
            System.out.println(hd);
        }
        sc.close();
    }
}
