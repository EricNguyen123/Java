/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
public class MaTranNhiPhan {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] a = new int[n];
        int d = 0;
        for(int i = 0; i < n; i++){
            int b = 0;
            for(int j = 0; j < 3; j++){
               int x = sc.nextInt();
               if(x == 1){
                   b++;
               }
            }
            if(b >= 2){
                d++;
            }
        }
        System.out.println(d);
    }
}
