/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
public class TinhThuNhapGiaoVien {
    public static void main(String[] args){
        Scanner sc= new Scanner(System.in);
        String code = sc.nextLine();
        String name = sc.nextLine();
        long salary = sc.nextLong();
        if(code.contains("HT")){
            int bl = ((int)code.charAt(2) - 48) * 10 + (int)code.charAt(3) - 48;
            salary = salary * bl + 2000000;
            System.out.print(code + " " + name + " " + bl + " 2000000" + " " + salary);
        }
        else if(code.contains("HP")){
            int bl = ((int)code.charAt(2) - 48) * 10 + (int)code.charAt(3) - 48;
            salary = salary * bl + 900000;
            System.out.print(code + " " + name + " " + bl + " 900000" + " " + salary);
        }
        else{
            int bl = ((int)code.charAt(2) - 48) * 10 + (int)code.charAt(3) - 48;
            salary = salary * bl + 500000;
            System.out.print(code + " " + name + " " + bl + " 500000" + " " + salary);
        }
    }
}
