package main.java.com.mycompany.ptitjava;

public class HV extends HinhPhang {
    private long a;

    public HV(long a) {
        this.a = a;
    }

    @Override
    public long ChuVi() {
        return 4 * a;
    }

    @Override
    public long DienTich() {
        return a * a;
    }

    @Override
    public String toString() {
        return String.valueOf(ChuVi()) + " " + String.valueOf(DienTich());
    }
}
