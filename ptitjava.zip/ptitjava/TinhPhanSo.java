package main.java.com.mycompany.ptitjava;

import java.util.*;

class PhanSo {
    private long x, y;

    public long getX() {
        return x;
    }

    public long getY() {
        return y;
    }

    public void setX(long x) {
        this.x = x;
    }

    public void setY(long y) {
        this.y = y;
    }

    public PhanSo(long x, long y) {
        this.x = x;
        this.y = y;
    }

    public long gcd(long x, long y) {
        while (y != 0) {
            long tmp = x % y;
            x = y;
            y = tmp;
        }
        return x;
    }

    public PhanSo Tong(PhanSo a) {
        long tu = a.getX() * this.y + a.getY() * this.x;
        long mau = this.y * a.getY();
        long ucln = gcd(tu, mau);
        tu /= ucln;
        mau /= ucln;
        return new PhanSo(tu, mau);
    }

    public PhanSo Tich(PhanSo a) {
        long tu = this.x * a.getX();
        long mau = this.y * a.getY();
        long ucln = gcd(tu, mau);
        tu /= ucln;
        mau /= ucln;
        return new PhanSo(tu, mau);
    }

    @Override
    public String toString() {
        String res = String.valueOf(this.x) + "/" + String.valueOf(this.y);
        return res;
    }
}

public class TinhPhanSo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int t = scanner.nextInt();
        while (t-- > 0) {
            PhanSo a = new PhanSo(scanner.nextLong(), scanner.nextLong());
            PhanSo b = new PhanSo(scanner.nextLong(), scanner.nextLong());
            PhanSo c = a.Tong(b);
            c = c.Tich(c);
            PhanSo d = a.Tich(b.Tich(c));
            System.out.println(c.toString() + " " + d.toString());
        }
    }
}