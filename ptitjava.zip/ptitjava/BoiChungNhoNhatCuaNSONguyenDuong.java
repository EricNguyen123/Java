/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ptitjava;

/**
 *
 * @author huynguyen
 */
import java.util.*;
public class BoiChungNhoNhatCuaNSONguyenDuong {
    static long UCLN(long a, long b){
        while(b != 0){
            long tmp;
            tmp = a % b;
            a = b;
            b = tmp;
        }
        return a;
    }
    public static void main(String[] args){
        long[] res = new long[105];
        res[0] = 0;
        res[1] = 1;
        res[2] = 2;
        for(int i = 3; i <= 100; i++){
            res[i] = (long)(i * res[i - 1]) / UCLN((long)i, res[i - 1]);
        }
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        while(t > 0){
            t--;
            int n = sc.nextInt();
            System.out.println(res[n]);
        }
    }
}
