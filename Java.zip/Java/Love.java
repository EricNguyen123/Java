import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Love extends Frame implements ActionListener {
    Label label;
    Button[] button = new Button[30];
    Random rand = new Random();
    TextArea textArea;
    int kt;

    public Love() {
        super("Love");
        kt = 0;
        this.setLayout(null);

        label = new Label("Minh thich ban con ban co thich mk khong?", Label.CENTER);
        label.setSize(600, 100);
        label.setLocation(0, 0);
        this.add(label);

        int i = 0;
        for (int k = 0; k < 5; k++) {
            for (int j = 0; j < 6; j++) {
                button[i] = new Button();
                button[i].setSize(100, 100);
                button[i].setLocation(new Point(j + 100 * j, 100 + k + 100 * k));
                button[i].addActionListener(this);
                this.add(button[i]);
                i++;
            }
        }
        button[2].setLabel("Yes");
        button[3].setLabel("No");

        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                if (kt == 1) {
                    System.exit(0);
                }
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        for (int i = 0; i < 30; i++) {
            if (ae.getSource() == button[i]) {
                if (button[i].getLabel() == "No" && kt != 1) {
                    button[i].setLabel("");
                    int x = rand.nextInt(30);
                    while (button[x].getLabel() == "Yes") {
                        x = rand.nextInt(30);
                    }
                    button[x].setLabel("No");
                    break;

                } else if (button[i].getLabel() == "Yes") {
                    label.setText("I Love You!");
                    kt = 1;
                    // textArea.setText("I Love You");
                    break;
                }
            }

        }
    }

    public static void main(String[] args) {
        Love frame = new Love();
        frame.setSize(606, 606);
        frame.setVisible(true);
    }
}
