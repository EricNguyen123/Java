import java.util.*;

public class Sodoku {
    static void in_sodoku(int n, int[][] a) {
        for (int i = 0; i < n; i++) {
            if (i % 3 == 0 && i != 0) {
                System.out.println("------------------------");
            }
            for (int j = 0; j < n; j++) {
                if (j % 3 == 0 && j != 0) {
                    System.out.print("| ");
                }
                if (j == 8) {
                    System.out.println(a[i][j]);
                } else {
                    System.out.print(a[i][j] + " ");
                }
            }
        }
    }

    static int Giai(int n, int[][] a) {
        int Tim_thay = Tim_o_trong(n, a);
        int d = 0, c = 0;
        if (Tim_thay == 0) {
            return 1;
        } else {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (a[i][j] == 0) {
                        d = i;
                        c = j;
                        break;
                    }
                }
            }
        }
        for (int l = 1; l < 10; l++) {
            if (Kiem_tra(n, a, l, d, c) == 1) {
                a[d][c] = l;
                if (Giai(n, a) == 1) {
                    return 1;
                } else {
                    a[d][c] = 0;
                }
            }
        }
        return 0;
    }

    static int Tim_o_trong(int n, int[][] a) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (a[i][j] == 0) {
                    return 1;
                }
            }
        }
        return 0;
    }

    static int Kiem_tra(int n, int[][] a, int gia_tri, int dong, int cot) {
        for (int i = 0; i < n; i++) {
            if (a[i][cot] == gia_tri && i != dong) {
                return 0;
            }
        }
        for (int i = 0; i < n; i++) {
            if (a[dong][i] == gia_tri && i != cot) {
                return 0;
            }
        }
        int x = cot / 3;
        int y = dong / 3;
        for (int i = y * 3; i < y * 3 + 3; i++) {
            for (int j = x * 3; j < x * 3 + 3; j++) {
                if (a[i][j] == gia_tri && i != dong && j != cot) {
                    return 0;
                }
            }
        }
        return 1;
    }

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[][] a = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                a[i][j] = sc.nextInt();
            }
        }
        Giai(n, a);
        System.out.println("Loi giai:");
        in_sodoku(n, a);
    }
}
