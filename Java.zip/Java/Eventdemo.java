import java.awt.*;
import java.awt.event.*;

public class Eventdemo extends Frame implements ActionListener {
    Label label1, label2, labelkq;
    TextField txt1, txt2;
    Button btnCong, btnTru, btnNhan, btnChia, btnThoat;

    public Eventdemo() {
        super("May Tinh");
        this.setLayout(new GridLayout(5, 4));
        label1 = new Label("So thu nhat:");
        this.add(label1);
        txt1 = new TextField();
        this.add(txt1);
        this.add(new Label());
        this.add(new Label());

        label2 = new Label("So thu hai:");
        this.add(label2);
        txt2 = new TextField();
        this.add(txt2);
        this.add(new Label());
        this.add(new Label());

        labelkq = new Label();
        this.add(labelkq);
        this.add(new Label());
        this.add(new Label());
        this.add(new Label());

        btnCong = new Button("+");
        btnCong.addActionListener(this);
        this.add(btnCong);

        btnTru = new Button("-");
        btnTru.addActionListener(this);
        this.add(btnTru);

        btnNhan = new Button("x");
        btnNhan.addActionListener(this);
        this.add(btnNhan);

        btnChia = new Button(":");
        btnChia.addActionListener(this);
        this.add(btnChia);

        btnThoat = new Button("Thoat");
        btnThoat.addActionListener(this);
        this.add(btnThoat);

        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        float x = Float.parseFloat(txt1.getText());
        float y = Float.parseFloat(txt2.getText());
        float kq = 0;
        if (ae.getSource() == btnCong) {
            kq = x + y;
        }
        if (ae.getSource() == btnTru) {
            kq = x - y;
        }
        if (ae.getSource() == btnNhan) {
            kq = x * y;
        }
        if (ae.getSource() == btnChia) {
            kq = x / y;
        }
        if (ae.getSource() == btnThoat) {
            System.exit(0);
        }
        labelkq.setText("Ket qua = " + String.valueOf(kq));
    }

    public static void main(String[] args) {
        Eventdemo frame = new Eventdemo();
        frame.setSize(600, 150);
        frame.setVisible(true);
    }

}