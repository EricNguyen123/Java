import java.awt.*;
import java.awt.event.*;

public class MayTinh extends Frame implements ActionListener {
    Label label1;
    Button button1, button2, button3, button4, button5, button6, button7, button8, button9, button0;
    Button buttonAC, buttonCong, buttonTru, buttonNhan, buttonChia, buttonCham, buttonBang;
    String tmp = "";
    float kq = 0;
    String kt = "";

    public MayTinh() {
        super("May Tinh");
        this.setLayout(new GridLayout(5, 4));

        // thiet lap cac nhan hien thi:
        this.add(new Label());
        this.add(new Label());
        label1 = new Label();
        this.add(label1);
        // Tao cac nut:
        buttonAC = new Button("AC");
        buttonAC.addActionListener(this);
        this.add(buttonAC);

        button1 = new Button("1");
        button1.addActionListener(this);
        this.add(button1);

        button2 = new Button("2");
        button2.addActionListener(this);
        this.add(button2);

        button3 = new Button("3");
        button3.addActionListener(this);
        this.add(button3);

        buttonCong = new Button("+");
        buttonCong.addActionListener(this);
        this.add(buttonCong);

        button4 = new Button("4");
        button4.addActionListener(this);
        this.add(button4);

        button5 = new Button("5");
        button5.addActionListener(this);
        this.add(button5);

        button6 = new Button("6");
        button6.addActionListener(this);
        this.add(button6);

        buttonTru = new Button("-");
        buttonTru.addActionListener(this);
        this.add(buttonTru);

        button7 = new Button("7");
        button7.addActionListener(this);
        this.add(button7);

        button8 = new Button("8");
        button8.addActionListener(this);
        this.add(button8);

        button9 = new Button("9");
        button9.addActionListener(this);
        this.add(button9);

        buttonNhan = new Button("x");
        buttonNhan.addActionListener(this);
        this.add(buttonNhan);

        button0 = new Button("0");
        button0.addActionListener(this);
        this.add(button0);

        buttonCham = new Button(".");
        buttonCham.addActionListener(this);
        this.add(buttonCham);

        buttonBang = new Button("=");
        buttonBang.addActionListener(this);
        this.add(buttonBang);

        buttonChia = new Button(":");
        buttonChia.addActionListener(this);
        this.add(buttonChia);

        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == button0) {
            tmp += button0.getLabel();
            label1.setText(tmp);
        }
        if (ae.getSource() == button1) {
            tmp += button1.getLabel();
            label1.setText(tmp);
        }
        if (ae.getSource() == button2) {
            tmp += button2.getLabel();
            label1.setText(tmp);
        }
        if (ae.getSource() == button3) {
            tmp += button3.getLabel();
            label1.setText(tmp);
        }
        if (ae.getSource() == button4) {
            tmp += button4.getLabel();
            label1.setText(tmp);
        }
        if (ae.getSource() == button5) {
            tmp += button5.getLabel();
            label1.setText(tmp);
        }
        if (ae.getSource() == button6) {
            tmp += button6.getLabel();
            label1.setText(tmp);
        }
        if (ae.getSource() == button7) {
            tmp += button7.getLabel();
            label1.setText(tmp);
        }
        if (ae.getSource() == button8) {
            tmp += button8.getLabel();
            label1.setText(tmp);
        }
        if (ae.getSource() == button9) {
            tmp += button9.getLabel();
            label1.setText(tmp);
        }
        if (ae.getSource() == buttonCham) {
            tmp += buttonCham.getLabel();
            label1.setText(tmp);
        }

        if (ae.getSource() == buttonCong) {
            if (tmp != "") {
                if (kt == "+") {
                    kq += Float.parseFloat(tmp);
                } else if (kt == "-") {
                    kq -= Float.parseFloat(tmp);
                } else if (kt == "x") {
                    kq *= Float.parseFloat(tmp);
                } else if (kt == ":") {
                    kq /= Float.parseFloat(tmp);
                } else {
                    kq = Float.parseFloat(tmp);
                }
                if (Math.ceil(kq) == Math.floor(kq)) {
                    label1.setText(String.valueOf((int) kq));
                } else {
                    label1.setText(String.valueOf(kq));
                }

            }
            kt = "+";
            // label1.setText("+");

            tmp = "";

        }

        if (ae.getSource() == buttonTru) {
            if (tmp != "") {
                if (kt == "+") {
                    kq += Float.parseFloat(tmp);
                } else if (kt == "-") {
                    kq -= Float.parseFloat(tmp);
                } else if (kt == "x") {
                    kq *= Float.parseFloat(tmp);
                } else if (kt == ":") {
                    kq /= Float.parseFloat(tmp);
                } else {
                    kq = Float.parseFloat(tmp);
                }
                if (Math.ceil(kq) == Math.floor(kq)) {
                    label1.setText(String.valueOf((int) kq));
                } else {
                    label1.setText(String.valueOf(kq));
                }

            }
            kt = "-";
            // label1.setText("-");

            tmp = "";

        }

        if (ae.getSource() == buttonNhan) {
            if (tmp != "") {
                if (kt == "+") {
                    kq += Float.parseFloat(tmp);
                } else if (kt == "-") {
                    kq -= Float.parseFloat(tmp);
                } else if (kt == "x") {
                    kq *= Float.parseFloat(tmp);
                } else if (kt == ":") {
                    kq /= Float.parseFloat(tmp);
                } else {
                    kq = Float.parseFloat(tmp);
                }
                if (Math.ceil(kq) == Math.floor(kq)) {
                    label1.setText(String.valueOf((int) kq));
                } else {
                    label1.setText(String.valueOf(kq));
                }

            }
            kt = "x";
            // label1.setText("x");

            tmp = "";

        }

        if (ae.getSource() == buttonChia) {
            if (tmp != "") {
                if (kt == "+") {
                    kq += Float.parseFloat(tmp);
                } else if (kt == "-") {
                    kq -= Float.parseFloat(tmp);
                } else if (kt == "x") {
                    kq *= Float.parseFloat(tmp);
                } else if (kt == ":") {
                    kq /= Float.parseFloat(tmp);
                } else {
                    kq = Float.parseFloat(tmp);
                }
                if (Math.ceil(kq) == Math.floor(kq)) {
                    label1.setText(String.valueOf((int) kq));
                } else {
                    label1.setText(String.valueOf(kq));
                }

            }
            kt = ":";
            // label1.setText(":");

            tmp = "";

        }

        if (ae.getSource() == buttonBang) {
            if (kt == "+") {
                kq += Float.parseFloat(tmp);
            } else if (kt == "-") {
                kq -= Float.parseFloat(tmp);
            } else if (kt == "x") {
                kq *= Float.parseFloat(tmp);
            } else if (kt == ":") {
                kq /= Float.parseFloat(tmp);
            }
            if (Math.ceil(kq) == Math.floor(kq)) {
                label1.setText(String.valueOf((int) kq));
            } else {
                label1.setText(String.valueOf(kq));
            }

            tmp = "";

        }

        if (ae.getSource() == buttonAC) {
            label1.setText("");
            tmp = "";
            kq = 0;
            kt = "";
            buttonAC.setLabel("AC");
        } else {
            buttonAC.setLabel("C");
        }
    }

    // tao frame:
    public static void main(String[] args) {
        MayTinh frame = new MayTinh();
        frame.setSize(600, 400);
        frame.setVisible(true);
    }
}
