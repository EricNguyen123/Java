
import java.io.*;
import java.util.*;
import java.util.LinkedList;

public class Graph {
    private int V;
    private LinkedList<Integer> adj[];// luu cac dinh do thi
    // Ham ve do thi

    Graph(int v) {
        V = v;
        adj = new LinkedList[v];
        for (int i = 0; i < v; ++i)
            adj[i] = new LinkedList();
    }

    // Cap nhap cac canh cua do thi
    void addEdge(int v, int w) {
        adj[v].add(w);
        adj[w].add(v);
    }

    // chon mau cho dinh do thi
    void greedyColoring() {
        int result[] = new int[V]; // khoi tao so dinh
        // khoi tao cac dinh ban dau chua gan
        Arrays.fill(result, -1);
        // gan mau dau tien cho dinh
        result[0] = 0;
        // Một mảng tạm thời để lưu trữ các màu có sẵn. Sai
        // giá trị của available[cr] có nghĩa là màu cr là
        // được gán cho một trong các đỉnh liền kề của nó
        boolean available[] = new boolean[V];
        // Ban đầu, tất cả các màu đều có sẵn
        Arrays.fill(available, true);
        // Gán màu cho các đỉnh V-1 còn lại
        for (int u = 1; u < V; u++) {
            // Xử lý tất cả các đỉnh liền kề và đánh dấu màu của chúng
            // như không có
            Iterator<Integer> it = adj[u].iterator();
            while (it.hasNext()) {
                int i = it.next();
                if (result[i] != -1)
                    available[result[i]] = false;
            }
            // Tìm màu có sẵn đầu tiên
            int cr;
            for (cr = 0; cr < V; cr++) {
                if (available[cr])
                    break;
            }
            // Gán màu tìm được
            // Đặt lại các giá trị về true cho lần lặp tiếp theo
            result[u] = cr;
            Arrays.fill(available, true);
        }
        // in ra dinh voi mau tuong ung
        for (int u = 0; u < V; u++)
            System.out.println("Vertex " + u + " ---> Color "
                    + result[u]);
    }

    public static void main(String args[]) {
        int n;
        Scanner scanner = new Scanner(System.in);
        n = scanner.nextInt(); // nhap vao so dinh do thi
        Graph g1 = new Graph(n); // khoi tao do thi
        for (int i = 0; i < n; i++) {
            int x, y;
            x = scanner.nextInt();
            y = scanner.nextInt();
            g1.addEdge(x, y);// nhap vao canh do thi
        }
        g1.greedyColoring();// in ket qua
    }
}
